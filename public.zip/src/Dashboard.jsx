import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  AppBar,
  Autocomplete,
  Box,
  Button,
  Checkbox,
  Drawer,
  Fade,
  IconButton,
  InputBase,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Snackbar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableFooter,
  TableHead,
  TableRow,
  TextField,
  Toolbar,
  Typography,
} from '@mui/material';
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import CloseIcon from '@mui/icons-material/Close';
import KeyboardArrowDownRoundedIcon from '@mui/icons-material/KeyboardArrowDownRounded';
import ExcelJS from 'exceljs';
import { supabase } from './supabaseClient';
import {
  getFloorCellKeys,
  getProjectCellKeys,
} from './utils/buildingUnits.js';
import Sidebar from './components/Sidebar.jsx';
import MessengerButton from './components/MessengerButton.jsx';
import KoreanDatePicker from './components/KoreanDatePicker.jsx';
import MainDashboard from './page/MainDashboard.jsx';
import DailyReport from './page/DailyReport.jsx';
import MonthlyWorkerStatus from './page/MonthlyWorkerStatus.jsx';
import CumulativeWorkerStatus from './page/CumulativeWorkerStatus.jsx';
import ProgressInput from './page/ProgressInput.jsx';
import MultiProcessProgress from './page/MultiProcessProgress.jsx';
import CompletionSummary from './page/CompletionSummary.jsx';
import DailyCompletionSummary from './page/DailyCompletionSummary.jsx';
import WeeklyReport from './page/WeeklyReport.jsx';
import ProposalReport from './page/ProposalReport.jsx';
import ExpenseResolution from './page/ExpenseResolution.jsx';
import ApprovalInbox from './page/ApprovalInbox.jsx';
import WeeklyOverview from './page/WeeklyOverview.jsx';
import WeeklyOverviewArchive from './page/WeeklyOverviewArchive.jsx';
import MaterialOrderUpload from './page/MaterialOrderUpload.jsx';
import MaterialInputStatus from './page/MaterialInputStatus.jsx';
import UnitPriceAnalysis from './page/UnitPriceAnalysis.jsx';
import LaborContractManagement from './page/LaborContractManagement.jsx';
import MonthlyLaborManagement from './page/MonthlyLaborManagement.jsx';
import WorkerMasterManagement from './page/WorkerMasterManagement.jsx';
import LaborCostManagement from './page/LaborCostManagement.jsx';
import ProgressClaimManagement from './page/ProgressClaimManagement.jsx';
import ContractItemProcessMapping from './page/ContractItemProcessMapping.jsx';
import AdminDashboard from './page/AdminDashboard.jsx';
import UserManagementWithAccessHistory from './page/UserManagementWithAccessHistory.jsx';
import ProjectManagement from './page/ProjectManagement.jsx';
import OrganizationChart from './page/OrganizationChart.jsx';
import DrawingQuantityAnalysis from './page/DrawingQuantityAnalysis.jsx';
import Messenger from './page/Messenger.jsx';
import AttendanceManagement from './page/AttendanceManagement.jsx';

const drawerWidth = 240;
const SUPABASE_PAGE_SIZE = 1000;
const PROGRESS_WRITE_CHUNK_SIZE = 500;
const ALL_PROJECTS_OPTION = '전체현장';
const MANAGEMENT_AREA_CONSTRUCTION = 'construction';
const MANAGEMENT_AREA_SAFETY = 'safety';

const PROJECT_DISPLAY_ORDER = [
  '한라건설 용인금어지구',
  '현대건설 용인마크밸리',
  '대우건설 용인현장',
];

const PROJECT_FREE_VIEWS = [
  'admin-dashboard',
  'user-management',
  'project-management',
  'organization-chart',
  'messenger',
  'approval-inbox',
  'weekly-overview',
  'weekly-overview-archive',
  'daily-cumulative-workers',
  'labor-worker-master',
];

const sortProjectNames = (projectNames) =>
  [...projectNames].sort((first, second) => {
    const firstIndex =
      PROJECT_DISPLAY_ORDER.indexOf(first);
    const secondIndex =
      PROJECT_DISPLAY_ORDER.indexOf(second);

    if (firstIndex !== -1 || secondIndex !== -1) {
      if (firstIndex === -1) return 1;
      if (secondIndex === -1) return -1;
      return firstIndex - secondIndex;
    }

    return String(first).localeCompare(
      String(second),
      'ko',
    );
  });

const splitIntoChunks = (items, chunkSize) => {
  const chunks = [];

  for (let index = 0; index < items.length; index += chunkSize) {
    chunks.push(items.slice(index, index + chunkSize));
  }

  return chunks;
};

const fetchAllProgressRows = async ({
  projectName,
  processType,
}) => {
  const allRows = [];
  let from = 0;

  while (true) {
    const { data, error } = await supabase
      .from('unit_progress')
      .select('building, unit, status, completion_date, completion_worker_names')
      .eq('project_name', projectName)
      .eq('process_type', processType)
      .neq('status', '작업전')
      .order('building', { ascending: true })
      .order('unit', { ascending: true })
      .range(from, from + SUPABASE_PAGE_SIZE - 1);

    if (error) {
      throw error;
    }

    const rows = data || [];
    allRows.push(...rows);

    if (rows.length < SUPABASE_PAGE_SIZE) {
      break;
    }

    from += SUPABASE_PAGE_SIZE;
  }

  return allRows;
};

const fetchAllDailyReportRows = async (projectName) => {
  const allRows = [];
  let from = 0;

  while (true) {
    const { data, error } = await supabase
      .from('daily_reports')
      .select('*')
      .eq('project_name', projectName)
      .order('date', { ascending: true })
      .range(from, from + SUPABASE_PAGE_SIZE - 1);

    if (error) {
      throw error;
    }

    const rows = data || [];
    allRows.push(...rows);

    if (rows.length < SUPABASE_PAGE_SIZE) {
      break;
    }

    from += SUPABASE_PAGE_SIZE;
  }

  return allRows;
};

const getKoreaDateTimeParts = (date = new Date()) => {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  });

  const values = {};

  formatter.formatToParts(date).forEach((part) => {
    if (part.type !== 'literal') {
      values[part.type] = Number(part.value);
    }
  });

  return {
    year: values.year,
    month: values.month,
    day: values.day,
    hour: values.hour,
    minute: values.minute,
    second: values.second,
  };
};

const formatKoreaAccessDateTime = (value) => {
  if (!value) return '-';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '-';

  const parts = getKoreaDateTimeParts(date);
  const pad = (number) => String(number).padStart(2, '0');

  return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}[${pad(parts.hour)}:${pad(parts.minute)}:${pad(parts.second)}]`;
};

const createKoreaCalendarDate = (date = new Date()) => {
  const parts = getKoreaDateTimeParts(date);

  /*
    Date 객체는 화면 달력 계산용으로만 사용합니다.
    연/월/일 값은 반드시 한국시간에서 추출합니다.
  */
  return new Date(parts.year, parts.month - 1, parts.day);
};

const formatYYMMDD = (date) => {
  const yy = String(date.getFullYear()).slice(2);
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yy}.${mm}.${dd}`;
};

const formatYYYYMMDD = (dateStr) => {
  if (!dateStr) return '';
  return `20${dateStr.replace(/\./g, '-')}`;
};

const jobOptions = ['소장', '관리자', '직영', '먹매김', '단열', '합지', '경량벽체', '세대천정', '공용홀천정', '몰딩', '걸레받이', '수장', '외주', '기타', '용역'];

/*
  v52.29 과거 출력일보 직종명 최소 호환.
  공정(process)은 별도 세부공정이므로 이 함수로 변경하지 않습니다.
*/
const LEGACY_DAILY_REPORT_JOB_MAP = {
  먹메김: '먹매김',
  경량: '경량벽체',
  경량골조: '경량벽체',
  경량석고: '경량벽체',
  천정: '세대천정',
};

const normalizeDailyReportJob = (value) => {
  const normalized = String(value || '').trim();
  return LEGACY_DAILY_REPORT_JOB_MAP[normalized] || normalized;
};

const processOptions = ['바닥먹', '허리먹', '단열', '합지', '경량골조', '경량석고', '세대천정', '1차몰딩', '2차몰딩', '1차 걸레받이', '2차 걸레받이'];

const MARK_VALLEY_EXTRA_PROCESS = '조적단열';

const getProjectProcessOptions = (
  projectName,
) => {
  const normalizedProjectName =
    String(projectName || '')
      .replace(/\s+/g, '');

  const isMarkValley =
    normalizedProjectName.includes(
      '마크밸리',
    );

  if (!isMarkValley) {
    return processOptions;
  }

  const insulationIndex =
    processOptions.indexOf('단열');

  if (insulationIndex === -1) {
    return [
      ...processOptions,
      MARK_VALLEY_EXTRA_PROCESS,
    ];
  }

  return [
    ...processOptions.slice(
      0,
      insulationIndex + 1,
    ),
    MARK_VALLEY_EXTRA_PROCESS,
    ...processOptions.slice(
      insulationIndex + 1,
    ),
  ];
};

const modalStyle = {
  position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
  width: '95vw', maxWidth: '1600px', height: '82vh',
  bgcolor: 'background.paper', boxShadow: 24, borderRadius: '8px',
  display: 'flex', flexDirection: 'column', overflow: 'hidden',
};

const headerCellStyle = { borderRight: '1px solid #cbd5e1', fontWeight: 'bold', color: '#334155', py: 1 };
const bodyCellStyle = { borderRight: '1px solid #cbd5e1', p: 0 }; 

const viewTitles = {
  main: 'Main',
  'admin-dashboard': '전체 현장 Dashboard',
  'user-management': '회원관리',
  'project-management': '현장관리',
  'organization-chart': '조직도',
  messenger: '메신저',
  daily: '출력일보작성',
  'daily-monthly-workers': '금월 투입현황',
  'daily-cumulative-workers': '누계투입조회',
  'progress-input': '공종별 현황 입력',
  'progress-multi': '다중 공종 진척 현황',
  'progress-daily': '일별 완료 집계',
  'progress-weekly': '주별 완료 집계',
  'progress-monthly': '월별 완료 집계',
  'material-order': '자재발주작성',
  'material-input-status': '자재투입현황',
  'material-unit-price': '일위대가작성',
  'drawing-quantity': '타입별 도면분석',
  'payment-claim': '기성내역서작성',
  'payment-contract-mapping': '계약품목 공정연결',
  'payment-sales-status': '매입매출현황',
  'labor-monthly': '월별 노임작성',
  'labor-worker-master': '근로자 정보관리',
  'labor-contract': '근로계약서작성',
  'labor-cost': '공정별 노임작성',
  'report-weekly': '주간 업무 보고',
  'report-expense-resolution': '지출결의서 작성',
  'report-approval': '품의 보고',
  'report-outsourcing-approval': '외주 품의 보고',
  'report-accident': '사고 경위 보고',
  'approval-inbox': '결재함',
  'weekly-overview': '주간업무작성',
  'weekly-overview-archive': '주간업무보관',
  attendance: '근태관리',
};

const VIEW_PERMISSION_KEYS = {
  'admin-dashboard': 'construction.dashboard.view',
  main: 'common.main.view',
  'organization-chart': 'common.organization.view',
  'approval-inbox': 'approval.inbox.view',
  'weekly-overview': 'construction.weekly_overview.view',
  'weekly-overview-archive': 'construction.weekly_archive.view',
  daily: 'construction.daily_report.view',
  'daily-monthly-workers': 'construction.daily_monthly_workers.view',
  'daily-cumulative-workers': 'construction.daily_cumulative_workers.view',
  'progress-input': 'construction.progress.view',
  'progress-multi': 'construction.progress_multi.view',
  'progress-daily': 'construction.progress_daily.view',
  'progress-weekly': 'construction.progress_weekly.view',
  'progress-monthly': 'construction.progress_monthly.view',
  'drawing-quantity': 'construction.drawing.view',
  'material-order': 'material.order.view',
  'material-input-status': 'material.input.view',
  'material-unit-price': 'material.input.view',
  'payment-claim': 'claim.statement.view',
  'payment-contract-mapping': 'claim.process_link.view',
  'payment-sales-status': 'claim.sales.view',
  'labor-monthly': 'labor.cost.view',
  'labor-worker-master': 'labor.worker_master.manage',
  'labor-contract': 'labor.contract.view',
  'labor-cost': 'labor.cost.view',
  'report-weekly': 'report.weekly.view',
  'report-expense-resolution': 'report.expense.view',
  'report-approval': 'report.proposal.view',
  'report-outsourcing-approval': 'report.outsourcing.view',
  'report-accident': 'safety.incident.view',
  attendance: 'attendance.management.view',
};

const GLOBAL_PERMISSION_VIEWS = new Set([
  'approval-inbox',
  'weekly-overview',
  'weekly-overview-archive',
  'organization-chart',
  'labor-worker-master',
]);

const normalizeRuntimeAccess = (value) => {
  if (!value || typeof value !== 'object') return null;

  return {
    accessScope: String(value.access_scope || '').trim(),
    projectNames: Array.isArray(value.project_names)
      ? value.project_names.map((item) => String(item || '').trim()).filter(Boolean)
      : [],
    templatePermissions: Array.isArray(value.template_permissions)
      ? value.template_permissions.map((item) => String(item || '').trim()).filter(Boolean)
      : [],
    permissionOverrides: Array.isArray(value.permission_overrides)
      ? value.permission_overrides
          .map((item) => ({
            scopeKey: String(item?.scope_key || '').trim(),
            permissionKey: String(item?.permission_key || '').trim(),
            effect: String(item?.effect || '').trim(),
          }))
          .filter((item) => item.scopeKey && item.permissionKey && ['allow', 'deny'].includes(item.effect))
      : [],
    specialPermissions: Array.isArray(value.special_permissions)
      ? value.special_permissions.map((item) => String(item || '').trim()).filter(Boolean)
      : [],
    permissionTemplateCode: String(value.permission_template_code || '').trim(),
    runtimeSource: String(value.runtime_source || '').trim(),
  };
};

function ReportPlaceholder({ title }) {
  return (
    <Paper
      variant="outlined"
      sx={{
        height: '100%',
        minHeight: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 1,
        borderColor: '#cbd5e1',
        bgcolor: '#ffffff',
        boxShadow: 'none',
      }}
    >
      <Typography variant="h6" fontWeight={800} color="#334155">
        {title}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        메뉴 연결 완료 / 테스트 후 적용 예정
      </Typography>
    </Paper>
  );
}

const normalizeUserRole = (role) => {
  const normalized = String(role || '')
    .trim()
    .toLowerCase()
    .replace(/[\s_\-()[\]{}<>]/g, '');

  if (
    normalized.includes('최고관리자') ||
    normalized.includes('superadmin') ||
    normalized.includes('masteradmin')
  ) {
    return '최고관리자';
  }

  if (
    normalized === '관리자' ||
    normalized === 'admin' ||
    normalized.includes('administrator')
  ) {
    return '관리자';
  }

  if (
    normalized === '안전관리자' ||
    normalized === 'safetymanager' ||
    normalized === 'safetyadmin'
  ) {
    return '안전관리자';
  }

  return '담당자';
};

const resolveUserRole = (profile) => {
  if (
    profile?.is_super_admin === true ||
    profile?.isSuperAdmin === true
  ) {
    return '최고관리자';
  }

  const roleCandidates = [
    profile?.role,
    profile?.user_role,
    profile?.userRole,
    profile?.permission,
    profile?.authority,
    profile?.access_level,
  ];

  for (const candidate of roleCandidates) {
    const resolved = normalizeUserRole(candidate);
    if (resolved === '최고관리자') return resolved;
  }

  for (const candidate of roleCandidates) {
    const resolved = normalizeUserRole(candidate);
    if (resolved === '관리자') return resolved;
  }

  for (const candidate of roleCandidates) {
    const resolved = normalizeUserRole(candidate);
    if (resolved === '안전관리자') return resolved;
  }

  return '담당자';
};

export default function Dashboard({ user, userProfile, onLogout }) {
  const profileUserRole = resolveUserRole(userProfile);
  const [authenticatedUserRole, setAuthenticatedUserRole] =
    useState('');
  const userRole = authenticatedUserRole || profileUserRole;
  const isSuperAdmin = userRole === '최고관리자';
  const isManagementRole = ['관리자', '최고관리자'].includes(userRole);
  const [runtimeAccess, setRuntimeAccess] = useState(null);
  const [runtimeAccessReady, setRuntimeAccessReady] = useState(false);

  useEffect(() => {
    let active = true;

    const loadAuthenticatedUserRole = async () => {
      if (!user?.id) {
        if (active) setAuthenticatedUserRole('');
        return;
      }

      const { data, error } = await supabase
        .from('user_profiles')
        .select('auth_user_id, role, account_status')
        .eq('auth_user_id', user.id)
        .maybeSingle();

      if (!active) return;

      if (error) {
        console.warn(
          '현재 로그인 사용자 권한 확인 실패:',
          error,
        );
        setAuthenticatedUserRole('');
        return;
      }

      if (!data || data.account_status === 'disabled') {
        setAuthenticatedUserRole('');
        return;
      }

      setAuthenticatedUserRole(resolveUserRole(data));
    };

    loadAuthenticatedUserRole();

    return () => {
      active = false;
    };
  }, [user?.id, userProfile?.role, userProfile?.account_status]);

  useEffect(() => {
    let active = true;

    const loadRuntimeAccess = async () => {
      if (!user?.id) {
        if (active) {
          setRuntimeAccess(null);
          setRuntimeAccessReady(true);
        }
        return;
      }

      try {
        const { data, error } = await supabase.rpc(
          'get_my_runtime_access_v2',
        );

        if (error) throw error;
        if (!active) return;

        setRuntimeAccess(normalizeRuntimeAccess(data));
      } catch (error) {
        console.warn(
          '런타임 권한 조회 실패 - 기존 역할 기준으로 임시 동작합니다:',
          error,
        );

        if (active) {
          setRuntimeAccess(null);
        }
      } finally {
        if (active) {
          setRuntimeAccessReady(true);
        }
      }
    };

    loadRuntimeAccess();

    const timer = window.setInterval(
      loadRuntimeAccess,
      60 * 1000,
    );
    const handleFocus = () => {
      loadRuntimeAccess();
    };

    window.addEventListener('focus', handleFocus);

    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener('focus', handleFocus);
    };
  }, [user?.id]);

  const dashboardStorageBase = `constructionManagementDashboard:${
    user?.id || user?.email || 'anonymous'
  }`;

  const readDashboardSessionValue = (key) => {
    try {
      return window.sessionStorage.getItem(
        `${dashboardStorageBase}:${key}`,
      ) || '';
    } catch (error) {
      console.warn('화면 상태 불러오기 실패:', error);
      return '';
    }
  };

  const [selectedProjectName, setSelectedProjectName] =
    useState(() =>
      readDashboardSessionValue('selectedProjectName'),
    );

  const [
    lastSelectedProjectName,
    setLastSelectedProjectName,
  ] = useState(() =>
    readDashboardSessionValue('lastSelectedProjectName'),
  );

  const [projectOptions, setProjectOptions] =
    useState([]);
  const [projectOptionsLoading, setProjectOptionsLoading] =
    useState(false);

  const runtimeProjectNames = runtimeAccess
    ? sortProjectNames(runtimeAccess.projectNames || [])
    : [];
  const runtimeProjectKey = runtimeProjectNames.join('\u0001');
  const hasAllProjectAccess = Boolean(
    runtimeAccess && runtimeAccess.accessScope === 'all',
  );
  const fallbackProjectName = String(
    userProfile?.project_name || '',
  ).trim();
  const accessibleProjectNames = runtimeAccess
    ? runtimeProjectNames
    : (
        fallbackProjectName &&
        fallbackProjectName !== '본사' &&
        fallbackProjectName !== ALL_PROJECTS_OPTION
          ? [fallbackProjectName]
          : []
      );

  const permissionTemplateSet = new Set(
    runtimeAccess?.templatePermissions || [],
  );
  const specialPermissionSet = new Set(
    runtimeAccess?.specialPermissions || [],
  );
  const permissionOverrideMap = new Map(
    (runtimeAccess?.permissionOverrides || []).map((item) => [
      `${item.scopeKey}:${item.permissionKey}`,
      item.effect,
    ]),
  );

  const hasPermission = (
    permissionKey,
    projectName = '',
  ) => {
    if (!permissionKey) return true;
    if (isSuperAdmin) return true;

    if (!runtimeAccessReady || !runtimeAccess) {
      return null;
    }

    let granted =
      permissionTemplateSet.has(permissionKey) ||
      specialPermissionSet.has(permissionKey);

    const commonEffect = permissionOverrideMap.get(
      `*:${permissionKey}`,
    );
    if (commonEffect) {
      granted = commonEffect === 'allow';
    }

    const normalizedProjectName = String(
      projectName || '',
    ).trim();

    if (normalizedProjectName) {
      const projectEffect = permissionOverrideMap.get(
        `${normalizedProjectName}:${permissionKey}`,
      );
      if (projectEffect) {
        granted = projectEffect === 'allow';
      }
    }

    return granted;
  };

  const legacyCanAccessView = (view) => {
    if (view === 'user-management' || view === 'project-management') return isSuperAdmin;
    if (
      [
        'admin-dashboard',
        'weekly-overview',
        'weekly-overview-archive',
      ].includes(view)
    ) {
      return isManagementRole;
    }
    return true;
  };

  const canAccessView = (
    view,
    projectName = '',
  ) => {
    if (view === 'messenger') return true;
    if (view === 'user-management' || view === 'project-management') return isSuperAdmin;

    if (
      view === 'admin-dashboard' &&
      runtimeAccessReady &&
      runtimeAccess &&
      !isSuperAdmin
    ) {
      if (hasAllProjectAccess) {
        return Boolean(
          hasPermission('construction.dashboard.view', ''),
        );
      }

      return accessibleProjectNames.some((project) =>
        hasPermission('construction.dashboard.view', project),
      );
    }

    const permissionKey = VIEW_PERMISSION_KEYS[view];
    if (!permissionKey) return true;

    const scopeProjectName = GLOBAL_PERMISSION_VIEWS.has(view)
      ? ''
      : projectName;

    const permissionResult = hasPermission(
      permissionKey,
      scopeProjectName,
    );

    return permissionResult === null
      ? legacyCanAccessView(view)
      : permissionResult;
  };

  const dashboardAllowedProjectNames =
    hasAllProjectAccess
      ? (
          canAccessView('admin-dashboard')
            ? null
            : []
        )
      : accessibleProjectNames.filter((projectName) =>
          hasPermission(
            'construction.dashboard.view',
            projectName,
          ) !== false,
        );

  const canEditAdminDashboard = Boolean(
    isSuperAdmin || (
      hasAllProjectAccess
        ? hasPermission('construction.dashboard.manage', '') === true
        : dashboardAllowedProjectNames.length > 0 &&
          dashboardAllowedProjectNames.every(
            (projectName) =>
              hasPermission(
                'construction.dashboard.manage',
                projectName,
              ) === true,
          )
    ),
  );

  const selectedProjectIsAccessible =
    selectedProjectName &&
    selectedProjectName !== ALL_PROJECTS_OPTION &&
    (
      hasAllProjectAccess ||
      accessibleProjectNames.includes(selectedProjectName)
    );

  const activeProjectName =
    selectedProjectName === ALL_PROJECTS_OPTION
      ? ''
      : selectedProjectIsAccessible
        ? selectedProjectName
        : (
            accessibleProjectNames.includes(fallbackProjectName)
              ? fallbackProjectName
              : accessibleProjectNames[0] || ''
          );

  const canManageAttendance = Boolean(
    isSuperAdmin ||
      hasPermission(
        'attendance.management.manage',
        activeProjectName,
      ) === true,
  );

  const cumulativeProjectScope =
    selectedProjectName === ALL_PROJECTS_OPTION &&
    hasAllProjectAccess
      ? ALL_PROJECTS_OPTION
      : activeProjectName;

  const activeProcessOptions =
    getProjectProcessOptions(
      activeProjectName,
    );

  const activeUserProfile = {
    ...(userProfile || {}),
    role: userRole,
    project_name: activeProjectName,
  };

  const recentAccessAt =
    user?.last_sign_in_at ||
    userProfile?.last_sign_in_at ||
    userProfile?.last_login_at ||
    userProfile?.last_access_at ||
    '';

  /*
    한국시간 기준 시계입니다.
    브라우저를 계속 열어둬도 자정과 23시 59분이 지나면
    오늘 표시와 자동 마감 상태가 1분 이내에 갱신됩니다.
  */
  const [koreaClock, setKoreaClock] = useState(() => new Date());
  const koreaNow = getKoreaDateTimeParts(koreaClock);
  const todayMidnight = new Date(
    koreaNow.year,
    koreaNow.month - 1,
    koreaNow.day,
  );

  const [open, setOpen] = useState(true);
  const [managementMenuAnchor, setManagementMenuAnchor] = useState(null);
  const [workAlertOpen, setWorkAlertOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [buildingConfigs, setBuildingConfigs] = useState({});
  const [selectedDateKey, setSelectedDateKey] = useState('');
  const [selectedDateDisplay, setSelectedDateDisplay] = useState('');

  const [viewYear, setViewYear] = useState(
    () => getKoreaDateTimeParts().year,
  );
  const [viewMonth, setViewMonth] = useState(
    () => getKoreaDateTimeParts().month - 1,
  );
  const [selectedWeekDate, setSelectedWeekDate] = useState(
    () => createKoreaCalendarDate(),
  );

  const [currentView, setCurrentView] = useState(() => {
    const requestedView = new URLSearchParams(
      window.location.search,
    ).get('view');

    if (
      requestedView === 'approval-inbox' &&
      isManagementRole
    ) {
      return 'approval-inbox';
    }

    if (
      [
        'weekly-overview',
        'weekly-overview-archive',
      ].includes(
        requestedView,
      ) &&
      isManagementRole
    ) {
      return requestedView;
    }

    const storedView =
      readDashboardSessionValue('currentView');

    if (
      storedView &&
      storedView !== 'messenger' &&
      Object.prototype.hasOwnProperty.call(
        viewTitles,
        storedView,
      )
    ) {
      return storedView;
    }

    return isManagementRole
      ? 'admin-dashboard'
      : 'main';
  });

  const previousViewBeforeMessengerRef = useRef(
    isManagementRole ? 'admin-dashboard' : 'main',
  );
  const messengerWindowRef = useRef(null);

  // v52.18:
  // 권한 정보는 포커스 복귀/주기 갱신 때 계속 새로 읽되,
  // 현재 업무 화면 자동 보정은 로그인 후 최초 1회만 수행합니다.
  // 다른 프로그램/브라우저 탭을 사용했다가 돌아와도
  // 작성 중인 화면이 Main으로 변경되지 않도록 보호합니다.
  const navigationAccessInitializedRef = useRef(false);

  useEffect(() => {
    navigationAccessInitializedRef.current = false;
  }, [user?.id]);

  const [managementArea, setManagementArea] = useState(() => {
    const requestedView = new URLSearchParams(
      window.location.search,
    ).get('view');

    if (requestedView) {
      return MANAGEMENT_AREA_CONSTRUCTION;
    }

    return readDashboardSessionValue('managementArea') ===
      MANAGEMENT_AREA_SAFETY
      ? MANAGEMENT_AREA_SAFETY
      : MANAGEMENT_AREA_CONSTRUCTION;
  });

  const workAlertTodayKey = [
    koreaNow.year,
    String(koreaNow.month).padStart(2, '0'),
    String(koreaNow.day).padStart(2, '0'),
  ].join('-');

  const workAlertHiddenStorageKey =
    `constructionManagementMainWorkAlertHidden:${user?.id || user?.email || 'anonymous'}:${workAlertTodayKey}`;

  /*
    담당자가 Main 화면에 들어올 때마다 확인합니다.
    - 오늘 하루 보지 않기 미선택: Main을 다시 열면 알림이 다시 표시됩니다.
    - 오늘 하루 보지 않기 선택: 한국시간 기준 해당 날짜 동안 표시하지 않습니다.
    - 자정이 지나면 storage key가 달라져 다음 날 다시 표시됩니다.
  */
  useEffect(() => {
    if (userRole !== '담당자' || currentView !== 'main') {
      setWorkAlertOpen(false);
      return;
    }

    try {
      const hiddenToday =
        window.localStorage.getItem(workAlertHiddenStorageKey) === '1';
      setWorkAlertOpen(!hiddenToday);
    } catch (error) {
      console.warn('Main 업무알림 숨김 상태 확인 실패:', error);
      setWorkAlertOpen(true);
    }
  }, [
    currentView,
    userRole,
    workAlertHiddenStorageKey,
  ]);

  const handleCloseWorkAlert = (hideToday = false) => {
    if (hideToday) {
      try {
        window.localStorage.setItem(
          workAlertHiddenStorageKey,
          '1',
        );
      } catch (error) {
        console.warn('Main 업무알림 오늘 숨김 저장 실패:', error);
      }
    }

    setWorkAlertOpen(false);
  };

  const [savedData, setSavedData] = useState({});
  const [manualStatus, setManualStatus] = useState({});

  const [workerRows, setWorkerRows] = useState([]);
  const [taskRows, setTaskRows] = useState([]);
  const [selectedWorkers, setSelectedWorkers] = useState([]);
  const [selectedTasks, setSelectedTasks] = useState([]);

  const [workerFetchDate, setWorkerFetchDate] = useState('');
  const [taskFetchDate, setTaskFetchDate] = useState('');

  const [selectedProcess, setSelectedProcess] = useState(() =>
    readDashboardSessionValue('selectedProcess') || processOptions[0],
  );
  const [selectedCells, setSelectedCells] = useState(new Set());
  const [selectedStatusAction, setSelectedStatusAction] = useState('작업완료'); 
  const [progressDate, setProgressDate] = useState(() =>
    formatYYYYMMDD(formatYYMMDD(createKoreaCalendarDate())),
  );
  const [dashboardToast, setDashboardToast] = useState(null);

  const showDashboardToast = (text, severity = 'info') => {
    setDashboardToast({
      severity,
      text,
    });
  };
  
  const [unitProgressData, setUnitProgressData] = useState({});
  const [unitProgressProjectName, setUnitProgressProjectName] = useState('');
  const [unitProgressProcess, setUnitProgressProcess] = useState('');

  useEffect(() => {
    const timer = window.setInterval(() => {
      setKoreaClock(new Date());
    }, 60 * 1000);

    return () => {
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    try {
      window.sessionStorage.setItem(
        `${dashboardStorageBase}:currentView`,
        currentView,
      );
      window.sessionStorage.setItem(
        `${dashboardStorageBase}:selectedProjectName`,
        selectedProjectName || '',
      );
      window.sessionStorage.setItem(
        `${dashboardStorageBase}:lastSelectedProjectName`,
        lastSelectedProjectName || '',
      );
      window.sessionStorage.setItem(
        `${dashboardStorageBase}:managementArea`,
        managementArea,
      );
      window.sessionStorage.setItem(
        `${dashboardStorageBase}:selectedProcess`,
        selectedProcess || processOptions[0],
      );
    } catch (error) {
      console.warn('화면 상태 저장 실패:', error);
    }
  }, [
    currentView,
    dashboardStorageBase,
    lastSelectedProjectName,
    managementArea,
    selectedProcess,
    selectedProjectName,
  ]);

  useEffect(() => {
    let active = true;

    const loadProjectOptions = async () => {
      if (runtimeAccessReady && runtimeAccess && !hasAllProjectAccess) {
        setProjectOptions(runtimeProjectNames);
        setProjectOptionsLoading(false);
        return;
      }

      if (
        runtimeAccessReady &&
        runtimeAccess &&
        hasAllProjectAccess
      ) {
        setProjectOptionsLoading(true);
      } else if (!isManagementRole) {
        setProjectOptions(accessibleProjectNames);
        setProjectOptionsLoading(false);
        return;
      } else {
        setProjectOptionsLoading(true);
      }

      try {
        const allRows = [];
        let from = 0;

        while (true) {
          const { data, error } = await supabase
            .from('building_settings')
            .select('project_name')
            .not('project_name', 'is', null)
            .order('project_name', {
              ascending: true,
            })
            .range(
              from,
              from + SUPABASE_PAGE_SIZE - 1,
            );

          if (error) throw error;

          const rows = data || [];
          allRows.push(...rows);

          if (rows.length < SUPABASE_PAGE_SIZE) break;
          from += SUPABASE_PAGE_SIZE;
        }

        const names = sortProjectNames(
          Array.from(
            new Set(
              allRows
                .map((row) => String(row?.project_name || '').trim())
                .filter(Boolean),
            ),
          ),
        );

        if (active) setProjectOptions(names);
      } catch (error) {
        console.error('접근 현장목록 조회 오류:', error);

        if (active) {
          setProjectOptions(
            runtimeAccess ? runtimeProjectNames : accessibleProjectNames,
          );
        }
      } finally {
        if (active) setProjectOptionsLoading(false);
      }
    };

    loadProjectOptions();

    const handleFocus = () => {
      loadProjectOptions();
    };

    window.addEventListener('focus', handleFocus);
    window.addEventListener('project-registry-changed', handleFocus);

    return () => {
      active = false;
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('project-registry-changed', handleFocus);
    };
  }, [
    accessibleProjectNames.join('\u0001'),
    hasAllProjectAccess,
    isManagementRole,
    runtimeAccessReady,
    runtimeProjectKey,
  ]);

  useEffect(() => {
    if (!userProfile) return;

    if (runtimeAccessReady && runtimeAccess && !hasAllProjectAccess) {
      const nextProjectName =
        selectedProjectIsAccessible
          ? selectedProjectName
          : (
              accessibleProjectNames.includes(fallbackProjectName)
                ? fallbackProjectName
                : accessibleProjectNames[0] || ''
            );

      if (nextProjectName !== selectedProjectName) {
        setSelectedProjectName(nextProjectName);
      }

      if (nextProjectName) {
        setLastSelectedProjectName(nextProjectName);
      }
    } else if (!runtimeAccess && !isManagementRole) {
      setSelectedProjectName(fallbackProjectName);
      if (fallbackProjectName) {
        setLastSelectedProjectName(fallbackProjectName);
      }
    }

    const requestedView = new URLSearchParams(
      window.location.search,
    ).get('view');

    /*
      v52.18:
      runtimeAccess는 창 focus 및 60초 주기로 갱신됩니다.
      기존에는 갱신할 때마다 아래 화면 보정 로직까지 다시 실행되어
      일반 담당자의 현장별 권한 판정 순간에 현재 화면이 Main으로
      변경될 수 있었습니다.

      화면 보정은 권한정보가 준비된 뒤 최초 1회만 수행하고,
      이후 focus/visibility/주기 갱신은 현재 currentView를 건드리지 않습니다.
    */
    if (
      !runtimeAccessReady ||
      navigationAccessInitializedRef.current
    ) {
      return;
    }

    if (
      requestedView &&
      Object.prototype.hasOwnProperty.call(viewTitles, requestedView) &&
      requestedView !== 'messenger' &&
      canAccessView(requestedView, activeProjectName)
    ) {
      setCurrentView(requestedView);
      navigationAccessInitializedRef.current = true;
      return;
    }

    setCurrentView((previousView) => {
      const storedView = readDashboardSessionValue('currentView');
      const candidates = [
        previousView,
        storedView,
        'main',
        'admin-dashboard',
        'approval-inbox',
        'weekly-overview',
        'weekly-overview-archive',
        'organization-chart',
        'daily',
        'progress-input',
      ];

      const allowedView = candidates.find(
        (view) =>
          view &&
          view !== 'messenger' &&
          Object.prototype.hasOwnProperty.call(viewTitles, view) &&
          canAccessView(view, activeProjectName),
      );

      return allowedView || 'main';
    });

    navigationAccessInitializedRef.current = true;
  }, [
    accessibleProjectNames.join('\u0001'),
    activeProjectName,
    fallbackProjectName,
    hasAllProjectAccess,
    isManagementRole,
    runtimeAccess,
    runtimeAccessReady,
    selectedProjectIsAccessible,
    selectedProjectName,
    userProfile,
  ]);

  const handleOpenAdminProject = (projectName) => {
    const normalizedProjectName = String(projectName || '').trim();

    if (
      !normalizedProjectName ||
      (
        runtimeAccess &&
        !hasAllProjectAccess &&
        !accessibleProjectNames.includes(normalizedProjectName)
      )
    ) {
      return;
    }

    setSelectedProjectName(normalizedProjectName);
    setLastSelectedProjectName(normalizedProjectName);

    if (canAccessView('main', normalizedProjectName)) {
      setCurrentView('main');
    }
  };

  const handleHistoricalUploadComplete = async (
    uploadedRows,
  ) => {
    if (
      !Array.isArray(uploadedRows) ||
      uploadedRows.length === 0
    ) {
      return;
    }

    setSavedData((previous) => {
      const next = {
        ...previous,
      };

      uploadedRows.forEach((row) => {
        next[row.date] = {
          workers:
            row.workers || [],
          tasks:
            row.tasks || [],
          todayTask:
            row.today_task || '',
          tomorrowTask:
            row.tomorrow_task || '',
        };
      });

      return next;
    });

    setManualStatus((previous) => {
      const next = {
        ...previous,
      };

      uploadedRows.forEach((row) => {
        next[row.date] =
          row.status || 'closed';
      });

      return next;
    });

    const firstDate =
      String(
        uploadedRows[0]?.date || '',
      ).split('.');

    if (
      firstDate.length === 3
    ) {
      const year =
        2000 +
        Number(firstDate[0]);
      const month =
        Number(firstDate[1]) - 1;

      if (
        Number.isInteger(year) &&
        Number.isInteger(month)
      ) {
        setViewYear(year);
        setViewMonth(month);
      }
    }
  };

  const handleSidebarViewChange = (nextView) => {
    if (
      ['user-management', 'project-management'].includes(nextView) &&
      !isSuperAdmin
    ) {
      return;
    }

    const permissionProjectName =
      GLOBAL_PERMISSION_VIEWS.has(nextView)
        ? ''
        : activeProjectName;

    if (
      !canAccessView(
        nextView,
        permissionProjectName,
      )
    ) {
      showDashboardToast(
        '이 메뉴에 대한 조회 권한이 없습니다.',
        'warning',
      );
      return;
    }

    if (
      nextView !== 'daily-cumulative-workers' &&
      selectedProjectName === ALL_PROJECTS_OPTION
    ) {
      const restoreProjectName =
        (
          hasAllProjectAccess &&
          lastSelectedProjectName
        )
          ? lastSelectedProjectName
          : accessibleProjectNames[0] || '';

      setSelectedProjectName(restoreProjectName);
    }

    setCurrentView(nextView);
  };

  const handleSelectManagementProject = (
    event,
    projectName,
  ) => {
    const nextProjectName =
      projectName || '';

    setSelectedProjectName(
      nextProjectName,
    );

    if (
      nextProjectName &&
      nextProjectName !==
        ALL_PROJECTS_OPTION
    ) {
      setLastSelectedProjectName(
        nextProjectName,
      );
    }
  };

  // 💡 공정이 변경될 때마다 화면에 선택되어 있던 세대와 팝업창을 즉시 지워줍니다.
  useEffect(() => {
    setSelectedCells(new Set());
  }, [selectedProcess]);

  /*
    마크밸리에서 조적단열을 선택한 뒤 다른 현장으로 이동하면
    해당 현장에는 조적단열이 없으므로 첫 번째 공정으로 되돌립니다.
  */
  useEffect(() => {
    const nextProcessOptions =
      getProjectProcessOptions(
        activeProjectName,
      );

    if (
      !nextProcessOptions.includes(
        selectedProcess,
      )
    ) {
      setSelectedProcess(
        nextProcessOptions[0],
      );
    }
  }, [
    activeProjectName,
    selectedProcess,
  ]);

  useEffect(() => {
    let active = true;

    if (!activeProjectName) {
      setBuildingConfigs({});
      setUnitProgressData({});
      setUnitProgressProjectName('');
      setUnitProgressProcess('');
      setSavedData({});
      setManualStatus({});
      return () => {
        active = false;
      };
    }

    const fetchBuildingConfigs = async () => {
        const { data, error } = await supabase.from("building_settings").select("*").eq("project_name", activeProjectName);
        if (error) return console.error(error);
        if (!active) return;
        const configs = {};
        data.forEach(row => { configs[row.building_name] = row.config_json; });
        setBuildingConfigs(configs);
    };

    const fetchUnitProgress = async () => {
      // 공정이 바뀔 때 이전 공정 색상이 잠시 남지 않도록 먼저 비웁니다.
      setUnitProgressData({});
      setUnitProgressProjectName('');
      setUnitProgressProcess('');

      try {
        /*
          Supabase REST 조회는 프로젝트 설정에 따라 한 번에
          최대 1,000행까지만 반환될 수 있습니다.

          1,275세대처럼 1,000건을 넘는 현장도 전부 표시되도록
          1,000건 단위로 마지막 페이지까지 반복 조회합니다.
        */
        const data = await fetchAllProgressRows({
          projectName: activeProjectName,
          processType: selectedProcess,
        });

        const mapped = {};

        data.forEach((row) => {
          mapped[`${row.building}-${row.unit}`] = {
            status: row.status,
            date: row.completion_date,
            workerNames: Array.isArray(row.completion_worker_names)
              ? row.completion_worker_names
              : [],
          };
        });

        if (!active) return;
        setUnitProgressData(mapped);
        setUnitProgressProjectName(activeProjectName);
        setUnitProgressProcess(selectedProcess);
      } catch (error) {
        if (active) {
          console.error('공정 데이터 전체 조회 오류:', error);
        }
      }
    };

    const fetchReports = async () => {
      try {
        const data = await fetchAllDailyReportRows(
          activeProjectName,
        );

        const newData = {};
        const newStatus = {};

        data.forEach((row) => {
          newData[row.date] = {
            workers: row.workers || [],
            tasks: row.tasks || [],
            todayTask: row.today_task || '',
            tomorrowTask: row.tomorrow_task || '',
          };

          if (row.status) {
            newStatus[row.date] = row.status;
          }
        });

        if (!active) return;
        setSavedData(newData);
        setManualStatus(newStatus);
      } catch (error) {
        console.error('공사일보 전체 조회 오류:', error);
      }
    };

    fetchBuildingConfigs();
    fetchUnitProgress();
    fetchReports();

    return () => {
      active = false;
    };
  }, [activeProjectName, selectedProcess]);

  const syncDataToDB = async (
    dateKey,
    dataOverrides = {},
    statusOverride = null,
  ) => {
    if (!activeProjectName || !user?.email) return false;

    const currentData = {
      ...(savedData[dateKey] || {}),
      ...dataOverrides,
    };
    const currentStatus =
      statusOverride !== null
        ? statusOverride
        : manualStatus[dateKey] || 'open';

    const { error } = await supabase
      .from('daily_reports')
      .upsert(
        {
          date: dateKey,
          project_name: activeProjectName,
          author_email: user.email,
          workers: currentData.workers || [],
          tasks: currentData.tasks || [],
          today_task: currentData.todayTask || '',
          tomorrow_task: currentData.tomorrowTask || '',
          status: currentStatus,
        },
        {
          onConflict: 'date, project_name',
        },
      );

    if (error) {
      throw error;
    }

    return true;
  };

  const updateDeadlineStatus = async (dateKey, newStatus) => {
    if (!activeProjectName) {
      throw new Error('선택된 현장이 없습니다.');
    }

    /*
      마감 상태는 관리자 화면의 로컬 상태에만 저장하면 안 됩니다.
      모든 사용자가 다시 로그인했을 때도 같은 상태를 읽을 수 있도록
      daily_reports에 open 또는 closed 상태가 반드시 존재해야 합니다.

      기존 일보 행:
      status만 수정하여 작성자와 기존 입력내용을 보존합니다.

      일보 행이 없는 날짜:
      빈 일보 행을 새로 생성하면서 status를 저장합니다.
      빈 행은 관리자 Dashboard에서 '일보 등록'으로 계산되지 않습니다.
    */
    const hasExistingReport =
      Object.prototype.hasOwnProperty.call(savedData, dateKey) ||
      Object.prototype.hasOwnProperty.call(manualStatus, dateKey);

    if (!hasExistingReport) {
      const inserted = await syncDataToDB(
        dateKey,
        {
          workers: [],
          tasks: [],
          todayTask: '',
          tomorrowTask: '',
        },
        newStatus,
      );

      if (!inserted) {
        throw new Error('마감 상태 행을 생성하지 못했습니다.');
      }

      return true;
    }

    const { data, error } = await supabase
      .from('daily_reports')
      .update({
        status: newStatus,
      })
      .eq('date', dateKey)
      .eq('project_name', activeProjectName)
      .select('date, status');

    if (error) {
      throw error;
    }

    if (!Array.isArray(data) || data.length === 0) {
      throw new Error(
        '마감 상태가 데이터베이스에 반영되지 않았습니다. Supabase UPDATE 권한을 확인해주세요.',
      );
    }

    return true;
  };

  const toggleDrawer = () => setOpen(!open);

  const handleOpenManagementMenu = (event) => {
    setManagementMenuAnchor(event.currentTarget);
  };

  const handleCloseManagementMenu = () => {
    setManagementMenuAnchor(null);
  };

  const handleToggleMessenger = () => {
    try {
      if (
        messengerWindowRef.current &&
        !messengerWindowRef.current.closed
      ) {
        messengerWindowRef.current.focus();
        return;
      }

      const targetUrl = new URL(window.location.href);
      targetUrl.searchParams.set('view', 'messenger-window');
      const messengerWindowName = 'wooklim-construction-messenger';
      const messengerFeatures =
        'popup=yes,width=1480,height=880,resizable=yes,scrollbars=yes';

      // v52.10: 같은 이름의 메신저 창이 이미 살아 있으면 URL을 다시 열어
      // 새로고침하지 않고 그 창만 앞으로 가져온다. Dashboard가 재렌더링되어
      // ref가 사라졌더라도 작성 중 메시지와 현재 대화방을 유지할 수 있다.
      const messengerWindow = window.open(
        '',
        messengerWindowName,
        messengerFeatures,
      );

      if (!messengerWindow) {
        showDashboardToast(
          '메신저 창을 열지 못했습니다. 브라우저의 팝업 차단을 해제해주세요.',
          'warning',
        );
        return;
      }

      try {
        const currentHref = messengerWindow.location?.href || '';
        const currentUrl =
          currentHref && currentHref !== 'about:blank'
            ? new URL(currentHref)
            : null;
        const alreadyMessenger =
          currentUrl?.searchParams?.get('view') === 'messenger-window';

        if (!alreadyMessenger) {
          messengerWindow.location.replace(targetUrl.toString());
        }
      } catch {
        // 동일 출처 확인이 불가능한 예외 상황에서만 메신저 주소로 이동한다.
        messengerWindow.location.href = targetUrl.toString();
      }

      messengerWindowRef.current = messengerWindow;
      messengerWindow.focus();
    } catch (error) {
      console.error('메신저 별도창 열기 오류:', error);
      showDashboardToast('메신저 창을 열지 못했습니다.', 'error');
    }
  };

  const handleSelectManagementArea = (area) => {
    setManagementArea(area);

    if (currentView === 'messenger') {
      setCurrentView(
        previousViewBeforeMessengerRef.current ||
          (canAccessView('admin-dashboard') ? 'admin-dashboard' : 'main'),
      );
    }

    handleCloseManagementMenu();
  };

  const buildWeekCards = (baseDate, db) => {
    const startOfWeek = new Date(baseDate);
    startOfWeek.setDate(baseDate.getDate() - baseDate.getDay()); 
    const dayNames = ['일', '월', '화', '수', '목', '금', '토'];
    return Array.from({ length: 7 }).map((_, idx) => {
      const d = new Date(startOfWeek); d.setDate(startOfWeek.getDate() + idx);
      const dateStr = formatYYMMDD(d);
      const dbEntry = db[dateStr] || {};
      const workers = Array.isArray(dbEntry.workers)
        ? dbEntry.workers
        : [];

      const jobCounts = workers.reduce((counts, worker) => {
        const job = normalizeDailyReportJob(worker?.job);
        if (!job) return counts;

        counts[job] = (counts[job] || 0) + 1;
        return counts;
      }, {});

      return {
        date: dateStr,
        dayName: dayNames[idx],
        isToday: d.getTime() === todayMidnight.getTime(),
        workers: workers.length,
        jobCounts,
      };
    });
  };

  const weekDays = buildWeekCards(selectedWeekDate, savedData);

  const generateCalendarCells = (year, month) => {
    const firstDay = new Date(year, month, 1).getDay(); const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells = [];
    for (let i = 0; i < firstDay; i++) cells.push(null);
    for (let i = 1; i <= daysInMonth; i++) cells.push(i);
    const totalCells = Math.ceil(cells.length / 7) * 7;
    while (cells.length < totalCells) cells.push(null);
    return cells;
  };
  const calendarCells = generateCalendarCells(viewYear, viewMonth);

  const handlePrevMonth = () => { if (viewMonth === 0) { setViewYear(y => y - 1); setViewMonth(11); } else setViewMonth(m => m - 1); };
  const handleNextMonth = () => { if (viewMonth === 11) { setViewYear(y => y + 1); setViewMonth(0); } else setViewMonth(m => m + 1); };
  const handleGoToToday = () => {
    const today = createKoreaCalendarDate();

    setViewYear(today.getFullYear());
    setViewMonth(today.getMonth());
    setSelectedWeekDate(today);
  };
  const handleGoToMonth = (year, month) => {
    const nextYear = Number(year);
    const nextMonth = Number(month);

    if (
      !Number.isInteger(nextYear) ||
      !Number.isInteger(nextMonth) ||
      nextMonth < 0 ||
      nextMonth > 11
    ) {
      return;
    }

    const isAlreadySelectedMonth =
      selectedWeekDate.getFullYear() === nextYear &&
      selectedWeekDate.getMonth() === nextMonth;

    setViewYear(nextYear);
    setViewMonth(nextMonth);
    setSelectedWeekDate(
      isAlreadySelectedMonth
        ? new Date(selectedWeekDate)
        : new Date(nextYear, nextMonth, 1),
    );
  };
  const handleDayClick = (day) => { if (!day) return; setSelectedWeekDate(new Date(viewYear, viewMonth, day)); };
  const isClosed = (dateStr) => {
    if (!dateStr) return false;

    // 사용자가 취소한 open 상태를 자동 마감보다 우선합니다.
    if (manualStatus[dateStr] === 'open') return false;
    if (manualStatus[dateStr] === 'closed') return true;

    const parts = dateStr.split('.');
    const targetDate = new Date(
      2000 + parseInt(parts[0], 10),
      parseInt(parts[1], 10) - 1,
      parseInt(parts[2], 10),
    );

    const targetTime = targetDate.getTime();
    const todayTime = todayMidnight.getTime();

    // 한국시간 기준 지난 날짜는 자동 마감입니다.
    if (targetTime < todayTime) return true;

    // 한국시간 기준 오늘은 23시 59분부터 자동 마감합니다.
    if (
      targetTime === todayTime &&
      koreaNow.hour === 23 &&
      koreaNow.minute >= 59
    ) {
      return true;
    }

    return false;
  };
  const handleToggleDeadline = async (dateStr) => {
    const currentlyClosed = isClosed(dateStr);

    const confirmed = window.confirm(
      currentlyClosed
        ? `[${dateStr}] 마감을 취소하시겠습니까?`
        : `[${dateStr}] 마감 처리하시겠습니까?`,
    );

    if (!confirmed) return;

    const newStatus = currentlyClosed ? 'open' : 'closed';

    try {
      await updateDeadlineStatus(dateStr, newStatus);

      setManualStatus((prev) => ({
        ...prev,
        [dateStr]: newStatus,
      }));

      showDashboardToast(
        currentlyClosed
          ? '마감이 취소되었습니다. 근로자 추가/수정이 가능합니다.'
          : '마감 처리되었습니다.',
        'success',
      );
    } catch (error) {
      console.error('마감 상태 변경 오류:', error);

      showDashboardToast(
        `마감 상태를 변경하지 못했습니다. ${
          error?.message || 'Supabase 권한 설정을 확인해주세요.'
        }`,
        'error',
      );
    }
  };
  
  const parseReportDateKey = (key) => {
    if (!key || typeof key !== 'string') return null;

    const [yy, mm, dd] = key.split('.').map(Number);

    if (
      !Number.isFinite(yy) ||
      !Number.isFinite(mm) ||
      !Number.isFinite(dd)
    ) {
      return null;
    }

    return new Date(2000 + yy, mm - 1, dd).getTime();
  };

  const cumulativeCellMap = [
    {
      job: '소장',
      labelCell: 'B8',
      todayCell: 'C8',
      previousCell: 'E8',
      totalCell: 'F8',
    },
    {
      job: '관리자',
      labelCell: 'B9',
      todayCell: 'C9',
      previousCell: 'E9',
      totalCell: 'F9',
    },
    {
      job: '직영',
      labelCell: 'B10',
      todayCell: 'C10',
      previousCell: 'E10',
      totalCell: 'F10',
    },
    {
      job: '먹매김',
      labelCell: 'B11',
      todayCell: 'C11',
      previousCell: 'E11',
      totalCell: 'F11',
    },
    {
      job: '단열',
      labelCell: 'B12',
      todayCell: 'C12',
      previousCell: 'E12',
      totalCell: 'F12',
    },
    {
      job: '합지',
      labelCell: 'B13',
      todayCell: 'C13',
      previousCell: 'E13',
      totalCell: 'F13',
    },
    {
      job: '경량벽체',
      labelCell: 'B14',
      todayCell: 'C14',
      previousCell: 'E14',
      totalCell: 'F14',
    },
    {
      job: '세대천정',
      labelCell: 'H8',
      todayCell: 'I8',
      previousCell: 'K8',
      totalCell: 'L8',
    },
    {
      job: '공용홀천정',
      labelCell: 'H9',
      todayCell: 'I9',
      previousCell: 'K9',
      totalCell: 'L9',
    },
    {
      job: '몰딩',
      labelCell: 'H10',
      todayCell: 'I10',
      previousCell: 'K10',
      totalCell: 'L10',
    },
    {
      job: '걸레받이',
      labelCell: 'H11',
      todayCell: 'I11',
      previousCell: 'K11',
      totalCell: 'L11',
    },
    {
      job: '수장',
      labelCell: 'H12',
      todayCell: 'I12',
      previousCell: 'K12',
      totalCell: 'L12',
    },
    {
      job: '외주',
      labelCell: 'H13',
      todayCell: 'I13',
      previousCell: 'K13',
      totalCell: 'L13',
    },
    {
      job: '기타',
      labelCell: 'H14',
      todayCell: 'I14',
      previousCell: 'K14',
      totalCell: 'L14',
    },
  ];

  const cloneWorksheetData = (value) => {
    if (value === null || value === undefined) {
      return value;
    }

    if (value instanceof Date) {
      return new Date(value.getTime());
    }

    if (typeof value !== 'object') {
      return value;
    }

    if (typeof structuredClone === 'function') {
      return structuredClone(value);
    }

    return JSON.parse(JSON.stringify(value));
  };

  const getWorksheetMergeRanges = (worksheet) => {
    const modelMerges = worksheet?.model?.merges;

    if (Array.isArray(modelMerges)) {
      return [...modelMerges];
    }

    /*
      ExcelJS 버전에 따라 model.merges 대신 내부 _merges에
      병합정보가 들어 있는 경우를 대비합니다.
    */
    if (worksheet?._merges) {
      return Object.values(worksheet._merges)
        .map((merge) => merge?.range)
        .filter(Boolean);
    }

    return [];
  };

  const createWorksheetFromTemplate = (
    workbook,
    templateWorksheet,
    sheetName,
  ) => {
    /*
      worksheet.model을 통째로 대입하면 두 번째 시트부터
      병합셀, 열 너비, 행 높이가 엑셀 저장 과정에서 깨질 수 있습니다.

      시트를 새로 만든 뒤 원본 양식의 각 구성요소를 명시적으로
      복사하여 모든 날짜 시트가 동일한 모양을 유지하도록 합니다.
    */
    const worksheet = workbook.addWorksheet(sheetName);

    worksheet.state = 'visible';
    worksheet.properties = cloneWorksheetData(
      templateWorksheet.properties,
    );
    worksheet.pageSetup = cloneWorksheetData(
      templateWorksheet.pageSetup,
    );
    worksheet.headerFooter = cloneWorksheetData(
      templateWorksheet.headerFooter,
    );
    worksheet.views = cloneWorksheetData(
      templateWorksheet.views || [],
    );

    if (templateWorksheet.autoFilter) {
      worksheet.autoFilter = cloneWorksheetData(
        templateWorksheet.autoFilter,
      );
    }

    for (
      let columnNumber = 1;
      columnNumber <= templateWorksheet.columnCount;
      columnNumber += 1
    ) {
      const sourceColumn =
        templateWorksheet.getColumn(columnNumber);
      const targetColumn = worksheet.getColumn(columnNumber);

      targetColumn.width = sourceColumn.width;
      targetColumn.hidden = sourceColumn.hidden;
      targetColumn.outlineLevel = sourceColumn.outlineLevel;
      targetColumn.style = cloneWorksheetData(
        sourceColumn.style || {},
      );
    }

    templateWorksheet.eachRow(
      { includeEmpty: true },
      (sourceRow, rowNumber) => {
        const targetRow = worksheet.getRow(rowNumber);

        targetRow.height = sourceRow.height;
        targetRow.hidden = sourceRow.hidden;
        targetRow.outlineLevel = sourceRow.outlineLevel;

        sourceRow.eachCell(
          { includeEmpty: true },
          (sourceCell, columnNumber) => {
            /*
              병합된 보조 셀은 나중에 mergeCells()로 다시 생성합니다.
              보조 셀의 값을 먼저 넣으면 병합 마스터 값이 덮어써질 수
              있으므로 제외합니다.
            */
            if (sourceCell.type === ExcelJS.ValueType.Merge) {
              return;
            }

            const targetCell =
              targetRow.getCell(columnNumber);

            targetCell.value = cloneWorksheetData(
              sourceCell.value,
            );
            targetCell.style = cloneWorksheetData(
              sourceCell.style || {},
            );

            if (sourceCell.dataValidation) {
              targetCell.dataValidation =
                cloneWorksheetData(
                  sourceCell.dataValidation,
                );
            }

            if (sourceCell.note) {
              targetCell.note = cloneWorksheetData(
                sourceCell.note,
              );
            }
          },
        );
      },
    );

    const mergeRanges =
      getWorksheetMergeRanges(templateWorksheet);

    mergeRanges.forEach((range) => {
      worksheet.mergeCells(range);
    });

    /*
      병합 후 마스터 셀의 스타일과 값을 한 번 더 적용합니다.
      mergeCells() 과정에서 병합셀 스타일이 재정리되는 ExcelJS
      동작 때문에 테두리나 정렬이 달라지는 것을 방지합니다.
    */
    mergeRanges.forEach((range) => {
      const startAddress = String(range).split(':')[0];
      const sourceCell =
        templateWorksheet.getCell(startAddress);
      const targetCell =
        worksheet.getCell(startAddress);

      targetCell.value = cloneWorksheetData(
        sourceCell.value,
      );
      targetCell.style = cloneWorksheetData(
        sourceCell.style || {},
      );
    });

    const sourceValidations =
      templateWorksheet?.dataValidations?.model;

    if (sourceValidations) {
      worksheet.dataValidations.model =
        cloneWorksheetData(sourceValidations);
    }

    return worksheet;
  };

  const clearDailyWorkerRows = (worksheet) => {
    for (let row = 18; row <= 57; row += 1) {
      ['B', 'C', 'D', 'E', 'F', 'H', 'I', 'J', 'K', 'L'].forEach(
        (column) => {
          worksheet.getCell(`${column}${row}`).value = null;
        },
      );
    }
  };

  const fillDailyReportWorksheet = ({
    worksheet,
    dateStr,
    dayName,
    workers = [],
  }) => {
    const parts = dateStr.split('.');
    const formattedDateForExcel = `20${parts[0]}년 ${parseInt(
      parts[1],
      10,
    )}월 ${parseInt(parts[2], 10)}일 ${dayName}요일`;

    worksheet.getCell('C3').value =
      activeProjectName || '현장명 미지정';
    worksheet.getCell('C4').value = '(주)욱림건설';
    worksheet.getCell('C5').value = formattedDateForExcel;

    clearDailyWorkerRows(worksheet);

    const selectedDateTime = parseReportDateKey(dateStr);
    // v52.48.5.42.2: 단일 일자 출력 시 전일누계는 해당 월 안에서만 계산합니다.
    // 월간 배포용 파일은 아래 월간 다운로드 로직에서 전일 시트 누계 수식으로 다시 연결합니다.
    const selectedMonthPrefix = String(dateStr || '').slice(0, 6);
    const previousJobCounts = {};

    Object.entries(savedData).forEach(
      ([reportDateKey, reportData]) => {
        const reportDateTime = parseReportDateKey(reportDateKey);

        if (
          reportDateTime === null ||
          selectedDateTime === null ||
          !String(reportDateKey).startsWith(selectedMonthPrefix) ||
          reportDateTime >= selectedDateTime
        ) {
          return;
        }

        const previousWorkers = Array.isArray(reportData?.workers)
          ? reportData.workers
          : [];

        previousWorkers.forEach((worker) => {
          const job = normalizeDailyReportJob(worker?.job);
          const name = String(worker?.name || '').trim();

          if (!job || !name) return;

          previousJobCounts[job] =
            (previousJobCounts[job] || 0) + 1;
        });
      },
    );

    cumulativeCellMap.forEach(
      ({
        job,
        labelCell,
        todayCell,
        previousCell,
        totalCell,
      }) => {
        worksheet.getCell(labelCell).value = job;
        worksheet.getCell(previousCell).value =
          previousJobCounts[job] || 0;
        worksheet.getCell(totalCell).value = {
          formula: `${todayCell}+${previousCell}`,
        };
      },
    );

    workers.slice(0, 80).forEach((worker, index) => {
      if (index < 40) {
        const row = 18 + index;

        worksheet.getCell(`B${row}`).value = normalizeDailyReportJob(worker.job) || '';
        worksheet.getCell(`C${row}`).value = worker.name || '';
        worksheet.getCell(`D${row}`).value =
          worker.process || worker.job || '';
        worksheet.getCell(`E${row}`).value = worker.location || '';
        worksheet.getCell(`F${row}`).value =
          worker.workContent || worker.work_content || '';
      } else {
        const row = 18 + (index - 40);

        worksheet.getCell(`H${row}`).value = normalizeDailyReportJob(worker.job) || '';
        worksheet.getCell(`I${row}`).value = worker.name || '';
        worksheet.getCell(`J${row}`).value =
          worker.process || worker.job || '';
        worksheet.getCell(`K${row}`).value = worker.location || '';
        worksheet.getCell(`L${row}`).value =
          worker.workContent || worker.work_content || '';
      }
    });
  };

  const downloadExcelWorkbook = async (workbook, fileName) => {
    workbook.calcProperties.fullCalcOnLoad = true;
    workbook.calcProperties.forceFullCalc = true;
    workbook.calcProperties.calcMode = 'auto';

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const loadDailyReportTemplate = async () => {
    const response = await fetch('/templates/출력일보.xlsx');

    if (!response.ok) {
      throw new Error('출력일보 양식 파일을 찾지 못했습니다.');
    }

    const arrayBuffer = await response.arrayBuffer();
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(arrayBuffer);

    if (!workbook.worksheets[0]) {
      throw new Error('출력일보 양식에 시트가 없습니다.');
    }

    return workbook;
  };

  const handleDownloadExcel = async (dayObj) => {
    const dateStr = dayObj.date;
    const workers = savedData[dateStr]?.workers || [];

    if (workers.length === 0) {
      showDashboardToast(
        `[${dateStr}] 일자에 등록된 인원이 없습니다.`,
        'warning',
      );
      return;
    }

    try {
      const workbook = await loadDailyReportTemplate();
      const worksheet = workbook.worksheets[0];

      fillDailyReportWorksheet({
        worksheet,
        dateStr,
        dayName: dayObj.dayName,
        workers,
      });

      await downloadExcelWorkbook(
        workbook,
        `출력일보_${dateStr}.xlsx`,
      );
    } catch (error) {
      console.error(error);
      showDashboardToast(
        '양식 파일을 불러오지 못했습니다. templates 폴더를 확인해주세요.',
        'error',
      );
    }
  };

  const handleDownloadMonthlyExcel = async () => {
    try {
      // v52.48.5.42: 화면에서 선택한 월을 기준으로 월간 출력일보를 생성합니다.
      // 현재월은 오늘까지, 과거/미래월은 해당 월 말일까지 생성합니다.
      // 미래월은 savedData가 없으므로 자연스럽게 빈 출력일보 양식으로 생성됩니다.
      const year = viewYear;
      const monthIndex = viewMonth;
      const month = monthIndex + 1;
      const currentYear = todayMidnight.getFullYear();
      const currentMonthIndex = todayMidnight.getMonth();
      const currentMonthValue = currentYear * 12 + currentMonthIndex;
      const selectedMonthValue = year * 12 + monthIndex;
      const isCurrentMonth = selectedMonthValue === currentMonthValue;
      const isFutureMonth = selectedMonthValue > currentMonthValue;
      const lastDay = isCurrentMonth
        ? todayMidnight.getDate()
        : new Date(year, monthIndex + 1, 0).getDate();
      const workbook = await loadDailyReportTemplate();
      const templateWorksheet = workbook.worksheets[0];
      const dayNames = ['일', '월', '화', '수', '목', '금', '토'];
      const worksheets = [];

      /*
        원본 양식에 7월 1일 데이터를 입력하기 전에
        2일~오늘 시트를 먼저 모두 복제합니다.

        그렇지 않으면 2일 이후 시트가 이미 1일 데이터가 입력된
        시트를 복제하게 되므로 양식 원본 상태가 유지되지 않습니다.
      */
      templateWorksheet.name = `${month}.1`;
      worksheets.push(templateWorksheet);

      for (let day = 2; day <= lastDay; day += 1) {
        worksheets.push(
          createWorksheetFromTemplate(
            workbook,
            templateWorksheet,
            `${month}.${day}`,
          ),
        );
      }

      for (let day = 1; day <= lastDay; day += 1) {
        const targetDate = new Date(year, monthIndex, day);
        const dateStr = formatYYMMDD(targetDate);
        const workers = isFutureMonth
          ? []
          : (savedData[dateStr]?.workers || []);
        const worksheet = worksheets[day - 1];

        // v52.48.5.42.1: Excel 하단의 날짜별 시트 탭에서 일요일은 빨간색으로 표시합니다.
        if (targetDate.getDay() === 0) {
          worksheet.properties.tabColor = { argb: 'FFFF0000' };
        } else if (worksheet.properties?.tabColor) {
          delete worksheet.properties.tabColor;
        }

        fillDailyReportWorksheet({
          worksheet,
          dateStr,
          dayName: dayNames[targetDate.getDay()],
          workers,
        });

        // v52.48.5.42.2: 월간 출력일보 전일누계는 월내 시트 수식으로 연결합니다.
        // 1일은 0으로 시작하고, 2일부터는 바로 전날 시트의 누계 셀을 참조합니다.
        cumulativeCellMap.forEach(({ previousCell, totalCell }) => {
          if (day === 1) {
            worksheet.getCell(previousCell).value = 0;
            return;
          }

          const previousWorksheet = worksheets[day - 2];
          const previousSheetName = String(
            previousWorksheet?.name || `${month}.${day - 1}`,
          ).replace(/'/g, "''");

          worksheet.getCell(previousCell).value = {
            formula: `'${previousSheetName}'!${totalCell}`,
          };
        });
      }

      await downloadExcelWorkbook(
        workbook,
        `출력일보_${year}년_${String(month).padStart(
          2,
          '0',
        )}월_1-${lastDay}일.xlsx`,
      );
    } catch (error) {
      console.error('금월 출력일보 생성 오류:', error);
      showDashboardToast(
        '금월 출력일보를 만들지 못했습니다. 양식 파일과 데이터를 확인해주세요.',
        'error',
      );
    }
  };

  const normalizeWorker = (worker, index = 0) => ({
    ...worker,
    id: worker?.id ?? `${Date.now()}-${index}-${Math.random()}`,
    job: normalizeDailyReportJob(worker?.job) || null,
    name: worker?.name ?? '',
    process: worker?.process || worker?.job || null,
    location: worker?.location || '',
    workContent: worker?.workContent || worker?.work_content || '',
    day: worker?.day ?? 1,
    night: worker?.night ?? 0,
  });

  const handleOpenModal = (day) => {
    if (isClosed(day.date)) {
      showDashboardToast(
        '마감된 일자입니다. 관리자에게 연락하여 주시기 바랍니다.',
        'warning',
      );
      return;
    }

    setSelectedDateKey(day.date);
    setSelectedDateDisplay(`${day.date} (${day.dayName})`);

    const parts = day.date.split('.');
    const targetDate = new Date(
      2000 + parseInt(parts[0], 10),
      parseInt(parts[1], 10) - 1,
      parseInt(parts[2], 10),
    );

    targetDate.setDate(targetDate.getDate() - 1);
    const prevDayStr = formatYYYYMMDD(formatYYMMDD(targetDate));

    setWorkerFetchDate(prevDayStr);
    setTaskFetchDate(prevDayStr);

    const currentData = savedData[day.date];
    setWorkerRows(
      (currentData?.workers || []).map((worker, index) =>
        normalizeWorker(worker, index),
      ),
    );
    setTaskRows(currentData?.tasks || []);
    setModalOpen(true);
  };
  const handleCloseModal = () => { setModalOpen(false); setSelectedWorkers([]); setSelectedTasks([]); };
  const handleCardTaskChange = (date, field, value) => { if (isClosed(date)) return; setSavedData(prev => ({ ...prev, [date]: { ...(prev[date] || { workers: [], tasks: [] }), [field]: value } })); };
  const handleTaskBlur = async (dateKey) => { await syncDataToDB(dateKey); };
  const handleSetNoTask = async (dateKey) => {
    if (isClosed(dateKey)) return;

    const confirmedNoTask = window.confirm(
      '"작업없음" 처리하시겠습니까?',
    );

    if (!confirmedNoTask) return;

    const confirmedClose = window.confirm(
      '마감처리 됩니다.\n\nY(확인) / N(취소)',
    );

    if (!confirmedClose) return;

    const overrides = {
      workers: [],
      tasks: [],
      todayTask: '작업없음',
      tomorrowTask: '작업없음',
    };

    setSavedData((prev) => ({
      ...prev,
      [dateKey]: {
        ...(prev[dateKey] || {}),
        ...overrides,
      },
    }));

    setManualStatus((prev) => ({
      ...prev,
      [dateKey]: 'closed',
    }));

    await syncDataToDB(dateKey, overrides, 'closed');
  };
  const handleFetchPreviousCardTasks = async (currentDateKey) => {
    if (isClosed(currentDateKey)) return;
    const parts = currentDateKey.split('.'); const curr = new Date(2000 + parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)); curr.setDate(curr.getDate() - 1);
    const prevDateKey = formatYYMMDD(curr); const prevData = savedData[prevDateKey];
    if (!prevData?.todayTask && !prevData?.tomorrowTask) {
      showDashboardToast('가져올 내용이 없습니다.', 'warning');
      return;
    }
    const overrides = { ...(savedData[currentDateKey] || {}), todayTask: prevData.todayTask, tomorrowTask: prevData.tomorrowTask };
    setSavedData(prev => ({ ...prev, [currentDateKey]: overrides })); await syncDataToDB(currentDateKey, overrides);
  };
  const handleSaveModal = async () => {
    const isValid = workerRows.every(
      (row) =>
        row.job &&
        row.name &&
        row.name.trim() !== '' &&
        row.process &&
        row.day !== '' &&
        row.day !== null,
    );

    if (!isValid) {
      showDashboardToast(
        '구분, 성명, 공정, 주간 항목을 확인해주세요.',
        'warning',
      );
      return;
    }

    const overrides = {
      workers: workerRows,
      tasks: taskRows,
    };

    setSavedData((prev) => ({
      ...prev,
      [selectedDateKey]: {
        ...(prev[selectedDateKey] || {}),
        ...overrides,
      },
    }));

    await syncDataToDB(selectedDateKey, overrides);
    handleCloseModal();
    showDashboardToast('안전하게 저장되었습니다!', 'success');
  };
  const suppressedEnterCellRef =
    useRef('');

  const workerGridInputRefs =
    useRef(new Map());

  const getWorkerCellKey = (
    rowIndex,
    columnIndex,
  ) =>
    `${rowIndex}:${columnIndex}`;

  const isEnterEvent = (
    event,
  ) =>
    event.key === 'Enter' ||
    event.code === 'NumpadEnter';

  const setWorkerGridInputRef = (
    rowIndex,
    columnIndex,
    node,
  ) => {
    const key =
      getWorkerCellKey(
        rowIndex,
        columnIndex,
      );

    if (node) {
      workerGridInputRefs.current.set(
        key,
        node,
      );
      return;
    }

    workerGridInputRefs.current.delete(
      key,
    );
  };

  const getWorkerGridInput = (
    rowIndex,
    columnIndex,
  ) => {
    const key =
      getWorkerCellKey(
        rowIndex,
        columnIndex,
      );

    const registeredInput =
      workerGridInputRefs.current.get(
        key,
      );

    if (
      registeredInput &&
      typeof registeredInput.focus ===
        'function'
    ) {
      return registeredInput;
    }

    return document.querySelector(
      `[data-worker-grid-input="true"]` +
        `[data-worker-row="${rowIndex}"]` +
        `[data-worker-column="${columnIndex}"]`,
    );
  };

  const focusWorkerGridCell = (
    rowIndex,
    columnIndex,
  ) => {
    const applyFocus = () => {
      const target =
        getWorkerGridInput(
          rowIndex,
          columnIndex,
        );

      if (
        !target ||
        typeof target.focus !==
          'function'
      ) {
        return false;
      }

      target.focus({
        preventScroll: true,
      });

      target.scrollIntoView?.({
        block: 'nearest',
        inline: 'nearest',
      });

      if (
        typeof target.select ===
          'function'
      ) {
        target.select();
      }

      return true;
    };

    const focusedImmediately =
      applyFocus();

    requestAnimationFrame(() => {
      setTimeout(() => {
        applyFocus();
      }, 0);
    });

    return focusedImmediately;
  };

  const handleWorkerGridKeyDown = (
    event,
    rowIndex,
    columnIndex,
  ) => {
    /*
      자동완성 목록이 열린 상태의 Enter는
      MUI의 항목 선택에 먼저 사용합니다.
      이어지는 keyup에서는 아래 이동을 한 번 건너뜁니다.
    */
    if (isEnterEvent(event)) {
      const isAutocompleteOpen =
        event.currentTarget?.getAttribute(
          'aria-expanded',
        ) === 'true' ||
        event.target?.getAttribute(
          'aria-expanded',
        ) === 'true';

      if (
        isAutocompleteOpen ||
        event.defaultPrevented
      ) {
        suppressedEnterCellRef.current =
          getWorkerCellKey(
            rowIndex,
            columnIndex,
          );
      }

      return;
    }

    if (
      event.key === 'ArrowUp' ||
      event.key === 'ArrowDown'
    ) {
      const isAutocompleteOpen =
        event.currentTarget?.getAttribute(
          'aria-expanded',
        ) === 'true' ||
        event.target?.getAttribute(
          'aria-expanded',
        ) === 'true';

      /*
        구분·공정 자동완성 목록이 열려 있으면
        방향키는 목록 항목 이동에 그대로 사용합니다.
      */
      if (isAutocompleteOpen) {
        return;
      }

      const nextRowIndex =
        event.key === 'ArrowUp'
          ? rowIndex - 1
          : rowIndex + 1;

      if (
        nextRowIndex < 0 ||
        nextRowIndex >=
          workerRows.length
      ) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      focusWorkerGridCell(
        nextRowIndex,
        columnIndex,
      );

      return;
    }

    if (event.key !== 'Tab') {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    const lastColumnIndex = 6;

    if (event.shiftKey) {
      if (columnIndex > 0) {
        focusWorkerGridCell(
          rowIndex,
          columnIndex - 1,
        );
        return;
      }

      if (rowIndex > 0) {
        focusWorkerGridCell(
          rowIndex - 1,
          lastColumnIndex,
        );
      }

      return;
    }

    if (
      columnIndex <
      lastColumnIndex
    ) {
      focusWorkerGridCell(
        rowIndex,
        columnIndex + 1,
      );
      return;
    }

    focusWorkerGridCell(
      rowIndex + 1,
      0,
    );
  };

  const handleWorkerNameKeyDown = (
    event,
    rowIndex,
  ) => {
    if (event.key === 'Tab') {
      event.preventDefault();
      event.stopPropagation();

      focusWorkerGridCell(
        rowIndex,
        event.shiftKey ? 0 : 2,
      );
      return;
    }

    handleWorkerGridKeyDown(
      event,
      rowIndex,
      1,
    );
  };

  const handleWorkerAutocompleteKeyDown = (
    event,
    rowIndex,
    columnIndex,
    muiKeyDown,
  ) => {
    const popupWasOpen =
      event.currentTarget?.getAttribute(
        'aria-expanded',
      ) === 'true' ||
      event.target?.getAttribute(
        'aria-expanded',
      ) === 'true';

    const isVerticalArrow =
      event.key === 'ArrowUp' ||
      event.key === 'ArrowDown';

    /*
      Tab은 자동완성 내부 처리보다 먼저 가로 이동시킵니다.

      자동완성 목록이 닫힌 상태의 ↑↓도
      목록을 새로 열지 않고 같은 열의 위·아래 행으로 이동합니다.
    */
    if (
      event.key === 'Tab' ||
      (
        isVerticalArrow &&
        !popupWasOpen
      )
    ) {
      handleWorkerGridKeyDown(
        event,
        rowIndex,
        columnIndex,
      );

      if (event.defaultPrevented) {
        return;
      }
    }

    muiKeyDown?.(event);

    if (
      isEnterEvent(event) &&
      popupWasOpen
    ) {
      suppressedEnterCellRef.current =
        getWorkerCellKey(
          rowIndex,
          columnIndex,
        );
    }

    /*
      Enter와 일반 키는 기존 처리 유지.
      Tab 및 ↑↓는 위에서 이미 처리했거나
      열린 자동완성 목록이 처리했으므로 중복 호출하지 않습니다.
    */
    if (
      event.key !== 'Tab' &&
      !isVerticalArrow
    ) {
      handleWorkerGridKeyDown(
        event,
        rowIndex,
        columnIndex,
      );
    }
  };

  const handleWorkerGridKeyUp = (
    event,
    rowIndex,
    columnIndex,
  ) => {
    if (!isEnterEvent(event)) {
      return;
    }

    /*
      한글 IME 조합 중인 Enter는 글자 확정에 사용하고,
      조합이 끝난 keyup에서만 이동합니다.
    */
    if (
      event.nativeEvent?.isComposing ||
      event.isComposing
    ) {
      return;
    }

    const cellKey =
      getWorkerCellKey(
        rowIndex,
        columnIndex,
      );

    if (
      suppressedEnterCellRef.current ===
      cellKey
    ) {
      suppressedEnterCellRef.current =
        '';
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    focusWorkerGridCell(
      rowIndex + 1,
      columnIndex,
    );
  };

  const handleFetchWorkers = () => {
    const targetKey = formatYYMMDD(new Date(workerFetchDate));
    const previousWorkers = savedData[targetKey]?.workers || [];

    if (previousWorkers.length === 0) {
      showDashboardToast('가져올 데이터가 없습니다.', 'warning');
      return;
    }

    const normalizedWorkers = previousWorkers.map((worker, index) =>
      normalizeWorker(
        {
          ...worker,
          id: `${Date.now()}-${index}-${Math.random()}`,
        },
        index,
      ),
    );

    if (
      workerRows.length > 0 &&
      !window.confirm('기존 내용을 지우고 가져오시겠습니까?')
    ) {
      setWorkerRows((prev) => [...prev, ...normalizedWorkers]);
      return;
    }

    setWorkerRows(normalizedWorkers);
  };

  const handleAddWorker = () =>
    setWorkerRows((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        job: null,
        name: '',
        process: null,
        location: '',
        workContent: '',
        day: 1,
        night: 0,
      },
    ]);

  const handleDeleteWorkers = () => {
    setWorkerRows((prev) =>
      prev.filter((row) => !selectedWorkers.includes(row.id)),
    );
    setSelectedWorkers([]);
  };

  const handleSelectAllWorkers = (event) =>
    setSelectedWorkers(
      event.target.checked ? workerRows.map((row) => row.id) : [],
    );

  const handleSelectWorker = (id) =>
    setSelectedWorkers((prev) =>
      prev.includes(id)
        ? prev.filter((item) => item !== id)
        : [...prev, id],
    );

  const handleWorkerChange = (id, field, value) =>
    setWorkerRows((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;

        if (field === 'job') {
          const shouldFollowJob = !row.process || row.process === row.job;
          return {
            ...row,
            job: value,
            process: shouldFollowJob ? value : row.process,
          };
        }

        return {
          ...row,
          [field]: value,
        };
      }),
    );
  const handleFetchTasks = () => { const targetKey = formatYYMMDD(new Date(taskFetchDate)); if (savedData[targetKey]?.tasks?.length > 0) { if (taskRows.length > 0 && !window.confirm('추가하시겠습니까?')) { setTaskRows(savedData[targetKey].tasks.map(t => ({ ...t, id: Date.now() + Math.random() }))); return; } setTaskRows(prev => [...prev, ...savedData[targetKey].tasks.map(t => ({ ...t, id: Date.now() + Math.random() }))]); } else showDashboardToast('가져올 데이터가 없습니다.', 'warning'); };
  const handleAddTask = () => setTaskRows([...taskRows, { id: Date.now(), taskName: '', amount: '' }]);
  const handleDeleteTasks = () => { setTaskRows(taskRows.filter(row => !selectedTasks.includes(row.id))); setSelectedTasks([]); };
  const handleSelectAllTasks = (e) => setSelectedTasks(e.target.checked ? taskRows.map(row => row.id) : []);
  const handleSelectTask = (id) => setSelectedTasks(selectedTasks.includes(id) ? selectedTasks.filter(item => item !== id) : [...selectedTasks, id]);
  const handleTaskChange = (id, field, value) => setTaskRows(prev => prev.map(row => row.id === id ? { ...row, [field]: value } : row));

  const isCompletedProgressCell = (
    cellKey,
  ) =>
    unitProgressData?.[
      cellKey
    ]?.status === '작업완료';

  /*
    기존 완료일 보호는 새로운 완료 처리에서만 적용합니다.

    완료:
    기존 완료 세대 선택·저장 제외

    작업전 / 작업중:
    완료 세대도 선택 가능
    잘못 처리한 완료 상태를 되돌리거나 변경할 수 있음
  */
  const shouldProtectCompletedProgress =
    selectedStatusAction ===
    '작업완료';

  // 공정 진척 관리: 현재 선택한 상태에 맞는 세대만 선택합니다.
  const handleFloorClick = (buildingName, floor) => {
    const config = buildingConfigs[buildingName];
    if (!config) return;

    const validCellKeys = getFloorCellKeys(
      buildingName,
      config,
      floor,
    );

    const editableCellKeys =
      shouldProtectCompletedProgress
        ? validCellKeys.filter(
            (cellKey) =>
              !isCompletedProgressCell(
                cellKey,
              ),
          )
        : validCellKeys;

    if (
      editableCellKeys.length ===
      0
    ) {
      return;
    }

    setSelectedCells((prev) => {
      const next = new Set(prev);
      const allSelected =
        editableCellKeys.length > 0 &&
        editableCellKeys.every(
          (key) =>
            next.has(key),
        );

      editableCellKeys.forEach((key) => {
        if (allSelected) next.delete(key);
        else next.add(key);
      });

      return next;
    });
  };

  const handleGridCellClick = (
    cellKey,
  ) => {
    if (
      shouldProtectCompletedProgress &&
      isCompletedProgressCell(
        cellKey,
      )
    ) {
      return;
    }

    setSelectedCells(prev => {
      const next = new Set(prev);
      if (next.has(cellKey)) next.delete(cellKey);
      else next.add(cellKey);
      return next;
    });
  };

  const splitProgressCellKey = (cellKey) => {
    const separatorIndex = cellKey.lastIndexOf('-');

    if (separatorIndex === -1) {
      return {
        building: '',
        unit: cellKey,
      };
    }

    return {
      building: cellKey.slice(0, separatorIndex),
      unit: cellKey.slice(separatorIndex + 1),
    };
  };

  const handleSaveProgress = async () => {
    if (!activeProjectName) {
      setDashboardToast({
        severity: 'error',
        text: '선택된 현장이 없습니다.',
      });
      return;
    }

    if (selectedCells.size === 0) {
      setDashboardToast({
        severity: 'warning',
        text: '변경할 세대를 선택해주세요.',
      });
      return;
    }

    const todayProgressDate =
      formatYYYYMMDD(
        formatYYMMDD(
          createKoreaCalendarDate(),
        ),
      );

    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(
        progressDate,
      )
    ) {
      setDashboardToast({
        severity: 'warning',
        text: '공정 완료일을 올바르게 선택해주세요.',
      });
      return;
    }

    if (
      progressDate >
      todayProgressDate
    ) {
      setProgressDate(
        todayProgressDate,
      );
      setDashboardToast({
        severity: 'warning',
        text: '공정 완료일은 오늘 이후 날짜로 저장할 수 없습니다.',
      });
      return;
    }

    const allSelectedCellKeys =
      Array.from(
        selectedCells,
      );

    /*
      화면 선택 상태가 오래 남아 있거나
      다른 선택 기능을 통해 완료 세대가 포함되더라도,
      저장 직전에 다시 제외해 기존 완료일을 보호합니다.
    */
    const protectedCompletedCellKeys =
      shouldProtectCompletedProgress
        ? allSelectedCellKeys.filter(
            (cellKey) =>
              isCompletedProgressCell(
                cellKey,
              ),
          )
        : [];

    const selectedCellKeys =
      shouldProtectCompletedProgress
        ? allSelectedCellKeys.filter(
            (cellKey) =>
              !isCompletedProgressCell(
                cellKey,
              ),
          )
        : allSelectedCellKeys;

    if (
      selectedCellKeys.length ===
      0
    ) {
      setSelectedCells(
        new Set(),
      );

      setDashboardToast({
        severity: 'warning',
        text:
          '선택한 세대는 모두 이미 작업완료 상태입니다. 기존 완료일은 변경되지 않습니다.',
      });
      return;
    }

    try {
      /*
        작업전은 Supabase에 저장하지 않습니다.

        DB 행 없음 = 작업전
        작업중 = DB 저장
        작업완료 = DB 저장
      */
      if (selectedStatusAction === '작업전') {
        const unitsByBuilding = selectedCellKeys.reduce(
          (groups, cellKey) => {
            const { building, unit } = splitProgressCellKey(cellKey);

            if (!building || !unit) return groups;

            if (!groups[building]) {
              groups[building] = [];
            }

            groups[building].push(unit);
            return groups;
          },
          {},
        );

        const deleteResults = await Promise.all(
          Object.entries(unitsByBuilding).map(
            async ([building, units]) =>
              supabase
                .from('unit_progress')
                .delete()
                .eq('project_name', activeProjectName)
                .eq('process_type', selectedProcess)
                .eq('building', building)
                .in('unit', units),
          ),
        );

        const failedDelete = deleteResults.find(
          (result) => result.error,
        );

        if (failedDelete?.error) {
          throw failedDelete.error;
        }

        setUnitProgressData((prev) => {
          const next = {
            ...prev,
          };

          selectedCellKeys.forEach((cellKey) => {
            delete next[cellKey];
          });

          return next;
        });

        setSelectedCells(new Set());

        const protectedMessage =
          protectedCompletedCellKeys.length >
          0
            ? `\n이미 완료된 ${protectedCompletedCellKeys.length.toLocaleString()}세대는 변경하지 않았습니다.`
            : '';

        setDashboardToast({
          severity: 'success',
          text:
            `${selectedCellKeys.length.toLocaleString()}세대를 작업전으로 되돌렸습니다.${protectedMessage}`,
        });
        return;
      }

      const updates = selectedCellKeys.map((cellKey) => {
        const { building, unit } = splitProgressCellKey(cellKey);

        return {
          project_name: activeProjectName,
          building,
          unit,
          process_type: selectedProcess,
          status: selectedStatusAction,
          completion_date: progressDate,
          completion_worker_ids: [],
          completion_worker_names: [],
          completion_source: 'manual',
          completion_approval_group_id: null,
        };
      });

      /*
        전체선택 시 1,000세대를 넘는 현장도 안정적으로 저장되도록
        한 번에 모두 보내지 않고 500건 단위로 나눠서 저장합니다.
      */
      const updateChunks = splitIntoChunks(
        updates,
        PROGRESS_WRITE_CHUNK_SIZE,
      );

      for (const updateChunk of updateChunks) {
        const { error } = await supabase
          .from('unit_progress')
          .upsert(updateChunk, {
            onConflict:
              'project_name, building, unit, process_type',
          });

        if (error) {
          throw error;
        }
      }

      setUnitProgressData((prev) => {
        const next = {
          ...prev,
        };

        selectedCellKeys.forEach((cellKey) => {
          next[cellKey] = {
            status: selectedStatusAction,
            date: progressDate,
            workerNames: [],
          };
        });

        return next;
      });

      setSelectedCells(new Set());

      const protectedMessage =
        protectedCompletedCellKeys.length >
        0
          ? `\n이미 완료된 ${protectedCompletedCellKeys.length.toLocaleString()}세대는 기존 완료일을 유지했습니다.`
          : '';

      setDashboardToast({
        severity: 'success',
        text:
          `${selectedCellKeys.length.toLocaleString()}세대가 저장되었습니다.${protectedMessage}`,
      });
    } catch (error) {
      console.error('공정 상태 저장 오류:', error);
      setDashboardToast({
        severity: 'error',
        text:
          `저장 실패: ${error?.message || '알 수 없는 오류'}`,
      });
    }
  };

  const validProjectCellKeys = getProjectCellKeys(buildingConfigs);
  const totalUnits = validProjectCellKeys.size;
  const completedUnits = Array.from(validProjectCellKeys).filter(
    (cellKey) => unitProgressData[cellKey]?.status === '작업완료',
  ).length;
  const progressPercentage =
    totalUnits === 0
      ? 0
      : ((completedUnits / totalUnits) * 100).toFixed(2);

  const actionName = selectedStatusAction === '작업완료' ? '완료' : selectedStatusAction;

  const globalConstructionViews = [
    'admin-dashboard',
    'user-management',
    'organization-chart',
    'messenger',
    'approval-inbox',
    'weekly-overview',
    'weekly-overview-archive',
    'labor-worker-master',
  ];
  const constructionLocationTitle =
    currentView === 'daily-cumulative-workers'
      ? cumulativeProjectScope
      : globalConstructionViews.includes(currentView)
        ? ''
        : activeProjectName || '현장을 선택해주세요';
  const constructionHeaderTitle = [
    constructionLocationTitle,
    viewTitles[currentView] || '현장 관리',
  ]
    .filter(Boolean)
    .join(' - ');
  const headerTitle =
    currentView === 'messenger'
      ? '메신저'
      : managementArea === MANAGEMENT_AREA_SAFETY
        ? '안전 관리'
        : constructionHeaderTitle;

  const managementAreaLabel =
    managementArea === MANAGEMENT_AREA_SAFETY
      ? '안전 관리'
      : '공사 관리';

  return (
    <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Snackbar
        key={dashboardToast?.text || 'dashboard-toast'}
        open={Boolean(dashboardToast)}
        autoHideDuration={3000}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        TransitionComponent={Fade}
        transitionDuration={{ enter: 220, exit: 500 }}
        onClose={(_event, reason) => {
          if (reason === 'clickaway') return;
          setDashboardToast(null);
        }}
        sx={{
          top: '72px !important',
          zIndex: (theme) => theme.zIndex.snackbar + 10,
          '& .MuiAlert-root': {
            width: 'max-content',
            minWidth: { xs: 280, sm: 420 },
            maxWidth: 'min(920px, calc(100vw - 32px))',
            boxShadow: '0 12px 30px rgba(15, 23, 42, 0.22)',
          },
          '& .MuiAlert-message': {
            whiteSpace: 'normal',
          },
        }}
      >
        <Alert
          severity={dashboardToast?.severity || 'info'}
          variant="filled"
          onClose={() => setDashboardToast(null)}
        >
          {dashboardToast?.text || ''}
        </Alert>
      </Snackbar>

      <AppBar
        position="absolute"
        sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, bgcolor: '#1e293b' }}
      >
        <Toolbar
          sx={{
            minHeight: '56px !important',
            px: '0 !important',
          }}
        >
          <Box
            sx={{
              width: open ? drawerWidth : 72,
              minWidth: open ? drawerWidth : 72,
              height: 56,
              px: open ? 1 : 0.5,
              display: 'flex',
              alignItems: 'center',
              gap: open ? 0.5 : 0.15,
              borderRight: '1px solid rgba(255,255,255,0.14)',
              boxSizing: 'border-box',
              transition: 'width 0.3s, min-width 0.3s, padding 0.3s',
            }}
          >
            <Box
              component="img"
              src="/images/wooklim-logo-transparent.png"
              alt="욱림건설 로고"
              sx={{
                width: open ? 47 : 31,
                height: open ? 34 : 27,
                flexShrink: 0,
                objectFit: 'contain',
                transition: 'width 0.3s, height 0.3s',
              }}
            />

            {open && (
              <Button
                id="management-area-button"
                aria-controls={
                  managementMenuAnchor
                    ? 'management-area-menu'
                    : undefined
                }
                aria-haspopup="true"
                aria-expanded={
                  managementMenuAnchor ? 'true' : undefined
                }
                onClick={handleOpenManagementMenu}
                endIcon={<KeyboardArrowDownRoundedIcon />}
                sx={{
                  minWidth: 0,
                  flexGrow: 1,
                  height: 40,
                  px: 0.75,
                  color: '#ffffff',
                  justifyContent: 'center',
                  fontSize: '0.9rem',
                  fontWeight: 900,
                  whiteSpace: 'nowrap',
                  '& .MuiButton-endIcon': {
                    ml: 0.35,
                  },
                  '&:hover': {
                    bgcolor: 'rgba(255,255,255,0.08)',
                  },
                }}
              >
                {managementAreaLabel}
              </Button>
            )}

            <IconButton
              color="inherit"
              aria-label={open ? '메뉴 접기' : '메뉴 펼치기'}
              onClick={toggleDrawer}
              sx={{
                width: 31,
                height: 40,
                ml: 'auto',
                flexShrink: 0,
                color: '#94a3b8',
                borderRadius: 0.8,
                '&:hover': {
                  color: '#ffffff',
                  bgcolor: 'rgba(255,255,255,0.08)',
                },
              }}
            >
              {open ? (
                <ChevronLeftRoundedIcon fontSize="small" />
              ) : (
                <ChevronRightRoundedIcon fontSize="small" />
              )}
            </IconButton>
          </Box>

          <Menu
            id="management-area-menu"
            anchorEl={managementMenuAnchor}
            open={Boolean(managementMenuAnchor)}
            onClose={handleCloseManagementMenu}
            MenuListProps={{
              'aria-labelledby': 'management-area-button',
              dense: true,
            }}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
            slotProps={{
              paper: {
                sx: {
                  mt: 0.5,
                  minWidth: 132,
                  border: '1px solid #cbd5e1',
                  boxShadow: '0 12px 28px rgba(15,23,42,0.24)',
                },
              },
            }}
          >
            <MenuItem
              selected={
                managementArea === MANAGEMENT_AREA_CONSTRUCTION
              }
              onClick={() =>
                handleSelectManagementArea(
                  MANAGEMENT_AREA_CONSTRUCTION,
                )
              }
              sx={{ fontSize: '0.82rem', fontWeight: 700 }}
            >
              공사 관리
            </MenuItem>
            <MenuItem
              selected={managementArea === MANAGEMENT_AREA_SAFETY}
              onClick={() =>
                handleSelectManagementArea(MANAGEMENT_AREA_SAFETY)
              }
              sx={{ fontSize: '0.82rem', fontWeight: 700 }}
            >
              안전 관리
            </MenuItem>
          </Menu>

          <Typography
            component="h1"
            variant="subtitle1"
            color="inherit"
            noWrap
            sx={{
              flexGrow: 1,
              minWidth: 0,
              px: 1.5,
              fontWeight: 'bold',
            }}
          >
            {headerTitle}
          </Typography>

          {managementArea === MANAGEMENT_AREA_CONSTRUCTION &&
            (
              hasAllProjectAccess ||
              projectOptions.length > 1 ||
              (!runtimeAccessReady && isManagementRole)
            ) &&
            ![
              'weekly-overview',
              'weekly-overview-archive',
              'user-management',
              'organization-chart',
              'messenger',
              'labor-worker-master',
            ].includes(
              currentView,
            ) && (
            <Box
              sx={{
                position: 'absolute',
                left: '50%',
                top: '50%',
                width: {
                  xs: 240,
                  md: 330,
                },
                maxWidth: '38vw',
                transform:
                  'translate(-50%, -50%)',
                zIndex: 2,
              }}
            >
              <Autocomplete
                size="small"
                options={
                  currentView === 'daily-cumulative-workers' &&
                  hasAllProjectAccess
                    ? [
                        ALL_PROJECTS_OPTION,
                        ...projectOptions,
                      ]
                    : projectOptions
                }
                value={
                  currentView ===
                  'daily-cumulative-workers'
                    ? cumulativeProjectScope
                    : activeProjectName ||
                      null
                }
                loading={projectOptionsLoading}
                disableClearable
                onChange={handleSelectManagementProject}
                noOptionsText="등록된 현장이 없습니다."
                loadingText="현장목록 불러오는 중..."
                isOptionEqualToValue={(
                  option,
                  value,
                ) => option === value}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="현장을 선택해주세요"
                    inputProps={{
                      ...params.inputProps,
                      readOnly: true,
                    }}
                  />
                )}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    minHeight: 36,
                    py: '0 !important',
                    pr: '34px !important',
                    color: '#ffffff',
                    bgcolor:
                      'rgba(255,255,255,0.13)',
                    borderRadius: 1.2,
                    fontSize: '0.78rem',
                    fontWeight: 900,
                    '& fieldset': {
                      borderColor:
                        'rgba(255,255,255,0.38)',
                    },
                    '&:hover fieldset': {
                      borderColor:
                        'rgba(255,255,255,0.72)',
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: '#7dd3fc',
                    },
                  },
                  '& .MuiInputBase-input': {
                    py: '7px !important',
                    textAlign: 'center',
                    color: '#ffffff',
                    cursor: 'pointer',
                  },
                  '& .MuiInputBase-input::placeholder': {
                    color: '#cbd5e1',
                    opacity: 1,
                  },
                  '& .MuiAutocomplete-popupIndicator': {
                    color: '#e2e8f0',
                  },
                  '& .MuiAutocomplete-clearIndicator': {
                    color: '#e2e8f0',
                  },
                }}
              />
            </Box>
          )}

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
            <MessengerButton
              userId={user?.id || userProfile?.auth_user_id || ''}
              active={false}
              onOpen={handleToggleMessenger}
            />

            <Box sx={{ textAlign: 'right', lineHeight: 1.15 }}>
              <Typography variant="caption" sx={{ display: 'block', color: '#e2e8f0' }}>
                접속자: {userProfile?.manager_name} ({userRole})
              </Typography>
              <Typography
                variant="caption"
                sx={{ display: 'block', mt: 0.15, color: '#94a3b8', fontSize: '0.64rem' }}
              >
                최근 접속일시: {formatKoreaAccessDateTime(recentAccessAt)}
              </Typography>
            </Box>

            <Button
              color="inherit"
              onClick={onLogout}
              size="small"
              sx={{ border: '1px solid rgba(255,255,255,0.5)' }}
            >
              로그아웃
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      <Drawer
        variant="permanent"
        open={open}
        sx={{
          width: open ? drawerWidth : 72,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: open ? drawerWidth : 72,
            boxSizing: 'border-box',
            overflowX: 'hidden',
            transition: 'width 0.3s',
            bgcolor: '#0f172a',
            color: 'white',
          },
        }}
      >
        <Toolbar sx={{ minHeight: '56px !important' }} />
        {managementArea === MANAGEMENT_AREA_CONSTRUCTION ? (
          <Sidebar
            currentView={currentView}
            onViewChange={handleSidebarViewChange}
            drawerOpen={open}
            userRole={userRole}
            canView={(view) =>
              canAccessView(
                view,
                GLOBAL_PERMISSION_VIEWS.has(view)
                  ? ''
                  : activeProjectName,
              )
            }
          />
        ) : (
          <Box
            sx={{
              mx: 0.75,
              mt: 0.75,
              px: open ? 1.5 : 0,
              py: 1.5,
              minHeight: 64,
              display: 'flex',
              flexDirection: 'column',
              alignItems: open ? 'flex-start' : 'center',
              justifyContent: 'center',
              gap: 0.4,
              color: '#e2e8f0',
              border: '1px solid #334155',
              borderRadius: 1.2,
              bgcolor: 'rgba(30,41,59,0.72)',
            }}
          >
            <Typography
              sx={{
                fontSize: open ? '0.82rem' : '0.8rem',
                fontWeight: 900,
                whiteSpace: 'nowrap',
              }}
            >
              {open ? '안전 관리' : '안'}
            </Typography>
            {open && (
              <Typography
                sx={{
                  color: '#94a3b8',
                  fontSize: '0.67rem',
                  lineHeight: 1.45,
                }}
              >
                안전관리 전용 메뉴 영역
              </Typography>
            )}
          </Box>
        )}
      </Drawer>

      <Box
        component="main"
        className="wooklim-admin-ui"
        sx={{
          flexGrow: 1,
          minWidth: 0,
          height: '100vh',
          display: 'flex',
          flexDirection: 'column',
          bgcolor: '#f1f5f9',
        }}
      >
        <Toolbar sx={{ minHeight: '56px !important' }} />

        <Box
          sx={{
            p: 2,
            flexGrow: 1,
            minHeight: 0,
            overflow:
              [
                'weekly-overview',
                'weekly-overview-archive',
              ].includes(
                currentView,
              )
                ? 'auto'
                : 'hidden',
          }}
        >
          {currentView === 'messenger' ? (
            <Messenger
              currentUserId={user?.id || userProfile?.auth_user_id || ''}
            />
          ) : managementArea === MANAGEMENT_AREA_SAFETY ? (
            <Paper
              variant="outlined"
              sx={{
                height: '100%',
                minHeight: 320,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 1,
                borderColor: '#cbd5e1',
                bgcolor: '#ffffff',
              }}
            >
              <Typography
                variant="h6"
                sx={{ color: '#0f172a', fontWeight: 900 }}
              >
                안전 관리
              </Typography>
              <Typography
                sx={{
                  color: '#64748b',
                  fontSize: '0.78rem',
                }}
              >
                안전관리 전용 영역이 준비되었습니다.
              </Typography>
              <Typography
                sx={{
                  color: '#94a3b8',
                  fontSize: '0.7rem',
                }}
              >
                다음 단계에서 안전관리 메뉴와 기능을 추가합니다.
              </Typography>
            </Paper>
          ) : (
            <>
          {currentView === 'admin-dashboard' &&
            canAccessView('admin-dashboard') && (
            <AdminDashboard
              processOptions={processOptions}
              onOpenProject={handleOpenAdminProject}
              allowedProjectNames={dashboardAllowedProjectNames}
              canEdit={canEditAdminDashboard}
            />
          )}

          {currentView === 'user-management' && isSuperAdmin && (
            <UserManagementWithAccessHistory currentUserId={user?.id || ''} />
          )}

          {currentView === 'project-management' && isSuperAdmin && (
            <ProjectManagement />
          )}

          {currentView === 'attendance' && activeProjectName &&
            canAccessView('attendance', activeProjectName) && (
              <AttendanceManagement
                projectName={activeProjectName}
                canManage={canManageAttendance}
                onLogout={onLogout}
              />
            )}

          {currentView === 'organization-chart' && (
            <OrganizationChart
              userRole={userRole}
              currentUserId={user?.id || ''}
            />
          )}

          {currentView === 'approval-inbox' &&
            canAccessView('approval-inbox') && (
            <ApprovalInbox />
          )}

          {currentView === 'weekly-overview' &&
            canAccessView('weekly-overview') && (
              <WeeklyOverview
                userProfile={activeUserProfile}
              />
            )}

          {currentView === 'weekly-overview-archive' &&
            canAccessView('weekly-overview-archive') && (
              <WeeklyOverviewArchive
                userProfile={activeUserProfile}
              />
            )}

          {currentView === 'main' && activeProjectName && (
            <MainDashboard
              projectName={activeProjectName}
              userRole={userRole}
              buildingConfigs={buildingConfigs}
              processOptions={activeProcessOptions}
              savedData={savedData}
              viewYear={viewYear}
              viewMonth={viewMonth}
              handlePrevMonth={handlePrevMonth}
              handleNextMonth={handleNextMonth}
              onNavigate={handleSidebarViewChange}
              workAlertOpen={
                userRole === '담당자' &&
                workAlertOpen
              }
              onCloseWorkAlert={handleCloseWorkAlert}
            />
          )}

          {currentView === 'daily' && activeProjectName && (
            <DailyReport
              weekDays={weekDays}
              calendarCells={calendarCells}
              viewYear={viewYear}
              viewMonth={viewMonth}
              selectedWeekDate={selectedWeekDate}
              savedData={savedData}
              isClosed={isClosed}
              handlePrevMonth={handlePrevMonth}
              handleNextMonth={handleNextMonth}
              handleGoToToday={handleGoToToday}
              handleGoToMonth={handleGoToMonth}
              handleDayClick={handleDayClick}
              handleOpenModal={handleOpenModal}
              handleDownloadExcel={handleDownloadExcel}
              handleDownloadMonthlyExcel={handleDownloadMonthlyExcel}
              handleToggleDeadline={handleToggleDeadline}
              handleSetNoTask={handleSetNoTask}
              todayMidnight={todayMidnight}
              formatYYMMDD={formatYYMMDD}
              userProfile={activeUserProfile}
              onHistoricalUploadComplete={
                handleHistoricalUploadComplete
              }
            />
          )}

          {currentView === 'daily-monthly-workers' &&
            activeProjectName && (
              <MonthlyWorkerStatus
                projectName={activeProjectName}
                savedData={savedData}
                viewYear={viewYear}
                viewMonth={viewMonth}
                handlePrevMonth={handlePrevMonth}
                handleNextMonth={handleNextMonth}
              />
            )}

          {currentView ===
            'daily-cumulative-workers' && (
              <CumulativeWorkerStatus
                projectScope={
                  cumulativeProjectScope
                }
                userRole={userRole}
              />
            )}

          {currentView === 'progress-input' && activeProjectName && (
            <ProgressInput
              projectName={activeProjectName || ''}
              selectedCells={selectedCells}
              actionName={actionName}
              progressDate={progressDate}
              setProgressDate={setProgressDate}
              handleSaveProgress={handleSaveProgress}
              setSelectedCells={setSelectedCells}
              selectedStatusAction={selectedStatusAction}
              setSelectedStatusAction={setSelectedStatusAction}
              protectCompleted={
                shouldProtectCompletedProgress
              }
              completedUnits={completedUnits}
              totalUnits={totalUnits}
              progressPercentage={progressPercentage}
              setSelectedProcess={setSelectedProcess}
              selectedProcess={selectedProcess}
              processOptions={activeProcessOptions}
              buildingConfigs={buildingConfigs}
              unitProgressData={unitProgressData}
              unitProgressProjectName={unitProgressProjectName}
              unitProgressProcess={unitProgressProcess}
              handleGridCellClick={handleGridCellClick}
              handleFloorClick={handleFloorClick}
            />
          )}

          {currentView === 'progress-multi' && activeProjectName && (
            <MultiProcessProgress
              projectName={activeProjectName || ''}
              processOptions={activeProcessOptions}
              buildingConfigs={buildingConfigs}
            />
          )}

          {currentView === 'progress-daily' && activeProjectName && (
            <DailyCompletionSummary
              projectName={activeProjectName || ''}
              processOptions={activeProcessOptions}
              buildingConfigs={buildingConfigs}
            />
          )}

          {currentView === 'progress-monthly' && activeProjectName && (
            <CompletionSummary
              mode="monthly"
              projectName={activeProjectName || ''}
              processOptions={activeProcessOptions}
              buildingConfigs={buildingConfigs}
            />
          )}

          {currentView === 'progress-weekly' && activeProjectName && (
            <CompletionSummary
              mode="weekly"
              projectName={activeProjectName || ''}
              processOptions={activeProcessOptions}
              buildingConfigs={buildingConfigs}
            />
          )}

          {currentView === 'drawing-quantity' && activeProjectName && (
            <DrawingQuantityAnalysis
              projectName={activeProjectName}
              userProfile={activeUserProfile}
            />
          )}

          {currentView ===
            'material-order' &&
            activeProjectName && (
              <MaterialOrderUpload
                projectName={activeProjectName}
                userProfile={activeUserProfile}
              />
            )}

          {currentView ===
            'material-input-status' &&
            activeProjectName && (
              <MaterialInputStatus
                projectName={activeProjectName}
              />
            )}

          {currentView ===
            'material-unit-price' &&
            activeProjectName && (
              <UnitPriceAnalysis
                projectName={activeProjectName}
                userProfile={activeUserProfile}
                projectOptions={accessibleProjectNames}
                isSuperAdmin={isSuperAdmin}
                canManage={Boolean(
                  isSuperAdmin ||
                    hasPermission(
                      'material.input.manage',
                      activeProjectName,
                    ) === true
                )}
                canManageTechnicalImages={Boolean(
                  isSuperAdmin ||
                    hasPermission(
                      'material.unit_price.tech_image.manage',
                      activeProjectName,
                    ) === true
                )}
              />
            )}

          {currentView ===
            'labor-monthly' &&
            activeProjectName && (
              <MonthlyLaborManagement
                projectName={activeProjectName}
              />
            )}

          {currentView ===
            'labor-worker-master' && (
              <WorkerMasterManagement
                canManage={Boolean(
                  isSuperAdmin ||
                    hasPermission(
                      'labor.worker_master.manage',
                      '',
                    ) === true
                )}
              />
            )}

          {currentView ===
            'labor-contract' &&
            activeProjectName && (
              <LaborContractManagement
                projectName={activeProjectName}
                userProfile={activeUserProfile}
              />
            )}

          {currentView ===
            'labor-cost' &&
            activeProjectName && (
              <LaborCostManagement
                projectName={activeProjectName}
                userProfile={activeUserProfile}
                processOptions={activeProcessOptions}
                buildingConfigs={buildingConfigs}
              />
            )}

          {currentView ===
            'payment-claim' &&
            activeProjectName && (
              <ProgressClaimManagement
                projectName={activeProjectName}
                userProfile={activeUserProfile}
                processOptions={activeProcessOptions}
              />
            )}

          {currentView ===
            'payment-contract-mapping' &&
            activeProjectName && (
              <ContractItemProcessMapping
                projectName={activeProjectName}
                userProfile={activeUserProfile}
                processOptions={activeProcessOptions}
              />
            )}

          {currentView === 'report-weekly' && activeProjectName && (
            <WeeklyReport
              userProfile={activeUserProfile}
              buildingConfigs={buildingConfigs}
            />
          )}

          {currentView === 'report-expense-resolution' && activeProjectName && (
            <ExpenseResolution userProfile={activeUserProfile} />
          )}

          {currentView === 'report-approval' && activeProjectName && (
            <ProposalReport userProfile={activeUserProfile} />
          )}

          {currentView === 'report-outsourcing-approval' && activeProjectName && (
            <ReportPlaceholder title="외주 품의 보고" />
          )}

          {currentView === 'report-accident' && activeProjectName && (
            <ReportPlaceholder title="사고 경위 보고" />
          )}

          {!PROJECT_FREE_VIEWS.includes(
              currentView,
            ) &&
            !activeProjectName && (
              <Paper
                variant="outlined"
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 1,
                  borderColor: '#cbd5e1',
                  bgcolor: '#ffffff',
                }}
              >
                <Typography
                  fontWeight={900}
                  color="#334155"
                >
                  상단 현장목록에서 현장을 선택해주세요.
                </Typography>
                <Typography
                  sx={{
                    color: '#64748b',
                    fontSize: '0.76rem',
                  }}
                >
                  현장 선택 후 현재 메뉴가 바로 표시됩니다.
                </Typography>
              </Paper>
            )}
            </>
          )}
        </Box>
      </Box>

      <Modal open={modalOpen} onClose={handleCloseModal}>
        <Box sx={modalStyle}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2, bgcolor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
            <Typography variant="subtitle1" fontWeight="bold" color="#334155">내장공사 / [{selectedDateDisplay}]</Typography>
            <IconButton onClick={handleCloseModal} size="small"><CloseIcon /></IconButton>
          </Box>

          <Box
            sx={{
              flexGrow: 1,
              p: 2,
              overflow: 'hidden',
              bgcolor: '#f1f5f9',
            }}
          >
            <Paper
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                p: 1.5,
              }}
            >
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  mb: 1,
                }}
              >
                <Box>
                  <Typography
                    variant="subtitle2"
                    fontWeight="bold"
                  >
                    근로자
                  </Typography>

                  <Box
                    sx={{
                      mt: 0.15,
                    }}
                  >
                    <Typography
                      sx={{
                        color: '#64748b',
                        fontSize: '0.62rem',
                        fontWeight: 700,
                        lineHeight: 1.35,
                      }}
                    >
                      TAB / Shift+TAB: 좌우 이동 · ↑↓: 같은 열의 위·아래 행 이동 · ENTER / 숫자패드 Enter: 아래 행 이동
                    </Typography>

                    <Typography
                      sx={{
                        color: '#94a3b8',
                        fontSize: '0.57rem',
                        fontWeight: 700,
                        lineHeight: 1.3,
                      }}
                    >
                      구분·공정 목록이 열려 있을 때 ↑↓ 키는 목록 항목 선택에 사용됩니다.
                    </Typography>
                  </Box>
                </Box>

                <Box
                  sx={{
                    display: 'flex',
                    gap: 0.5,
                    alignItems: 'center',
                  }}
                >
                  <KoreanDatePicker
                    size="small"
                    value={workerFetchDate}
                    onChange={setWorkerFetchDate}
                    ariaLabel="불러올 근로자 날짜"
                    sx={{ width: 138 }}
                    inputSx={{
                      py: 0.2,
                      fontSize: '0.75rem',
                    }}
                  />

                  <Button
                    variant="contained"
                    size="small"
                    onClick={handleFetchWorkers}
                    sx={{
                      bgcolor: '#0284c7',
                      fontSize: '0.7rem',
                      boxShadow: 'none',
                    }}
                  >
                    가져오기
                  </Button>

                  <Button
                    variant="contained"
                    size="small"
                    onClick={handleAddWorker}
                    sx={{
                      bgcolor: '#475569',
                      fontSize: '0.7rem',
                      boxShadow: 'none',
                    }}
                  >
                    추가
                  </Button>

                  <Button
                    variant="contained"
                    size="small"
                    onClick={handleDeleteWorkers}
                    sx={{
                      bgcolor: '#ef4444',
                      fontSize: '0.7rem',
                      boxShadow: 'none',
                    }}
                  >
                    삭제
                  </Button>
                </Box>
              </Box>

              <TableContainer
                sx={{
                  flexGrow: 1,
                  border: '1px solid #cbd5e1',
                  borderRadius: '4px',
                  bgcolor: 'white',
                }}
              >
                <Table
                  stickyHeader
                  size="small"
                  sx={{
                    minWidth: 1320,
                    tableLayout: 'fixed',
                  }}
                >
                  <TableHead>
                    <TableRow sx={{ bgcolor: '#f8fafc' }}>
                      <TableCell
                        padding="checkbox"
                        align="center"
                        sx={{
                          width: 54,
                          borderRight: '1px solid #cbd5e1',
                          fontWeight: 'bold',
                        }}
                      >
                        <Checkbox
                          size="small"
                          onChange={handleSelectAllWorkers}
                          checked={
                            workerRows.length > 0 &&
                            selectedWorkers.length === workerRows.length
                          }
                          indeterminate={
                            selectedWorkers.length > 0 &&
                            selectedWorkers.length < workerRows.length
                          }
                        />
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 52 }}
                      >
                        No.
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 125 }}
                      >
                        구분
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 120 }}
                      >
                        성명
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 125 }}
                      >
                        공정
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 150 }}
                      >
                        위치
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 420 }}
                      >
                        작업내용
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ ...headerCellStyle, width: 74 }}
                      >
                        주간
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{
                          width: 74,
                          py: 1,
                          fontWeight: 'bold',
                          color: '#334155',
                        }}
                      >
                        야간
                      </TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {workerRows.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={9}
                          align="center"
                          sx={{
                            py: 10,
                            color: 'text.secondary',
                            borderBottom: 'none',
                          }}
                        >
                          데이터가 존재하지 않습니다.
                        </TableCell>
                      </TableRow>
                    ) : (
                      workerRows.map((row, index) => (
                        <TableRow hover key={row.id}>
                          <TableCell
                            padding="checkbox"
                            align="center"
                            sx={{
                              borderRight: '1px solid #cbd5e1',
                            }}
                          >
                            <Checkbox
                              size="small"
                              checked={selectedWorkers.includes(row.id)}
                              onChange={() => handleSelectWorker(row.id)}
                            />
                          </TableCell>

                          <TableCell
                            align="center"
                            sx={{
                              py: 0.5,
                              color: '#334155',
                              borderRight: '1px solid #cbd5e1',
                            }}
                          >
                            {index + 1}
                          </TableCell>

                          <TableCell align="center" sx={bodyCellStyle}>
                            <Autocomplete
                              options={jobOptions}
                              value={row.job}
                              onChange={(_, newValue) =>
                                handleWorkerChange(row.id, 'job', newValue)
                              }
                              disableClearable
                              size="small"
                              autoHighlight
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  variant="standard"
                                  InputProps={{
                                    ...params.InputProps,
                                    disableUnderline: true,
                                  }}
                                  inputRef={(node) =>
                                    setWorkerGridInputRef(
                                      index,
                                      0,
                                      node,
                                    )
                                  }
                                  inputProps={{
                                    ...params.inputProps,
                                    className: `${
                                      params.inputProps?.className || ''
                                    } excel-input`,
                                    'data-worker-grid-input': 'true',
                                    'data-worker-row': index,
                                    'data-worker-column': 0,
                                  }}
                                  onKeyDown={(event) =>
                                    handleWorkerAutocompleteKeyDown(
                                      event,
                                      index,
                                      0,
                                      params.inputProps
                                        ?.onKeyDown,
                                    )
                                  }
                                  onKeyUp={(event) =>
                                    handleWorkerGridKeyUp(
                                      event,
                                      index,
                                      0,
                                    )
                                  }
                                  sx={{
                                    '& input': {
                                      py: 1,
                                      textAlign: 'center',
                                      fontSize: '0.78rem',
                                    },
                                  }}
                                />
                              )}
                            />
                          </TableCell>

                          <TableCell align="center" sx={bodyCellStyle}>
                            <InputBase
                              className="excel-input"
                              value={row.name}
                              inputRef={(node) =>
                                setWorkerGridInputRef(
                                  index,
                                  1,
                                  node,
                                )
                              }
                              inputProps={{
                                'data-worker-grid-input': 'true',
                                'data-worker-row': index,
                                'data-worker-column': 1,
                              }}
                              onKeyDown={(event) =>
                                handleWorkerNameKeyDown(
                                  event,
                                  index,
                                )
                              }
                              onKeyUp={(event) =>
                                handleWorkerGridKeyUp(
                                  event,
                                  index,
                                  1,
                                )
                              }
                              onChange={(event) =>
                                handleWorkerChange(
                                  row.id,
                                  'name',
                                  event.target.value,
                                )
                              }
                              sx={{
                                width: '100%',
                                px: 0.7,
                                input: {
                                  textAlign: 'center',
                                  fontSize: '0.78rem',
                                },
                              }}
                            />
                          </TableCell>

                          <TableCell align="center" sx={bodyCellStyle}>
                            <Autocomplete
                              options={jobOptions}
                              value={row.process}
                              onChange={(_, newValue) =>
                                handleWorkerChange(
                                  row.id,
                                  'process',
                                  newValue,
                                )
                              }
                              disableClearable
                              size="small"
                              autoHighlight
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  variant="standard"
                                  InputProps={{
                                    ...params.InputProps,
                                    disableUnderline: true,
                                  }}
                                  inputRef={(node) =>
                                    setWorkerGridInputRef(
                                      index,
                                      2,
                                      node,
                                    )
                                  }
                                  inputProps={{
                                    ...params.inputProps,
                                    className: `${
                                      params.inputProps?.className || ''
                                    } excel-input`,
                                    'data-worker-grid-input': 'true',
                                    'data-worker-row': index,
                                    'data-worker-column': 2,
                                  }}
                                  onKeyDown={(event) =>
                                    handleWorkerAutocompleteKeyDown(
                                      event,
                                      index,
                                      2,
                                      params.inputProps
                                        ?.onKeyDown,
                                    )
                                  }
                                  onKeyUp={(event) =>
                                    handleWorkerGridKeyUp(
                                      event,
                                      index,
                                      2,
                                    )
                                  }
                                  sx={{
                                    '& input': {
                                      py: 1,
                                      textAlign: 'center',
                                      fontSize: '0.78rem',
                                    },
                                  }}
                                />
                              )}
                            />
                          </TableCell>

                          <TableCell align="center" sx={bodyCellStyle}>
                            <InputBase
                              className="excel-input"
                              value={row.location}
                              inputRef={(node) =>
                                setWorkerGridInputRef(
                                  index,
                                  3,
                                  node,
                                )
                              }
                              inputProps={{
                                'data-worker-grid-input': 'true',
                                'data-worker-row': index,
                                'data-worker-column': 3,
                              }}
                              onKeyDown={(event) =>
                                handleWorkerGridKeyDown(
                                  event,
                                  index,
                                  3,
                                )
                              }
                              onKeyUp={(event) =>
                                handleWorkerGridKeyUp(
                                  event,
                                  index,
                                  3,
                                )
                              }
                              onChange={(event) =>
                                handleWorkerChange(
                                  row.id,
                                  'location',
                                  event.target.value,
                                )
                              }
                              placeholder="예: 101동 3층"
                              sx={{
                                width: '100%',
                                px: 0.8,
                                input: {
                                  textAlign: 'center',
                                  fontSize: '0.78rem',
                                },
                              }}
                            />
                          </TableCell>

                          <TableCell align="center" sx={bodyCellStyle}>
                            <InputBase
                              className="excel-input"
                              value={row.workContent}
                              inputRef={(node) =>
                                setWorkerGridInputRef(
                                  index,
                                  4,
                                  node,
                                )
                              }
                              inputProps={{
                                'data-worker-grid-input': 'true',
                                'data-worker-row': index,
                                'data-worker-column': 4,
                              }}
                              onKeyDown={(event) =>
                                handleWorkerGridKeyDown(
                                  event,
                                  index,
                                  4,
                                )
                              }
                              onKeyUp={(event) =>
                                handleWorkerGridKeyUp(
                                  event,
                                  index,
                                  4,
                                )
                              }
                              onChange={(event) =>
                                handleWorkerChange(
                                  row.id,
                                  'workContent',
                                  event.target.value,
                                )
                              }
                              placeholder="작업내용을 입력하세요"
                              sx={{
                                width: '100%',
                                px: 1,
                                input: {
                                  fontSize: '0.78rem',
                                },
                              }}
                            />
                          </TableCell>

                          <TableCell align="center" sx={bodyCellStyle}>
                            <InputBase
                              className="excel-input"
                              type="number"
                              value={row.day}
                              inputRef={(node) =>
                                setWorkerGridInputRef(
                                  index,
                                  5,
                                  node,
                                )
                              }
                              inputProps={{
                                min: 0,
                                step: 0.5,
                                'data-worker-grid-input': 'true',
                                'data-worker-row': index,
                                'data-worker-column': 5,
                              }}
                              onKeyDown={(event) =>
                                handleWorkerGridKeyDown(
                                  event,
                                  index,
                                  5,
                                )
                              }
                              onKeyUp={(event) =>
                                handleWorkerGridKeyUp(
                                  event,
                                  index,
                                  5,
                                )
                              }
                              onChange={(event) =>
                                handleWorkerChange(
                                  row.id,
                                  'day',
                                  Number(event.target.value),
                                )
                              }
                              sx={{
                                width: '100%',
                                input: {
                                  textAlign: 'center',
                                  fontSize: '0.78rem',
                                },
                              }}
                            />
                          </TableCell>

                          <TableCell align="center" sx={{ p: 0 }}>
                            <InputBase
                              className="excel-input"
                              type="number"
                              value={row.night}
                              inputRef={(node) =>
                                setWorkerGridInputRef(
                                  index,
                                  6,
                                  node,
                                )
                              }
                              inputProps={{
                                min: 0,
                                step: 0.5,
                                'data-worker-grid-input': 'true',
                                'data-worker-row': index,
                                'data-worker-column': 6,
                              }}
                              onKeyDown={(event) =>
                                handleWorkerGridKeyDown(
                                  event,
                                  index,
                                  6,
                                )
                              }
                              onKeyUp={(event) =>
                                handleWorkerGridKeyUp(
                                  event,
                                  index,
                                  6,
                                )
                              }
                              onChange={(event) =>
                                handleWorkerChange(
                                  row.id,
                                  'night',
                                  Number(event.target.value),
                                )
                              }
                              sx={{
                                width: '100%',
                                input: {
                                  textAlign: 'center',
                                  fontSize: '0.78rem',
                                },
                              }}
                            />
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>

                  <TableFooter>
                    <TableRow sx={{ bgcolor: '#f1f5f9' }}>
                      <TableCell
                        colSpan={7}
                        align="center"
                        sx={{
                          py: 1.5,
                          fontWeight: 'bold',
                          color: '#334155',
                          borderRight: '1px solid #cbd5e1',
                        }}
                      >
                        합 계
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{
                          fontWeight: 'bold',
                          color: '#0284c7',
                          fontSize: '0.9rem',
                          borderRight: '1px solid #cbd5e1',
                        }}
                      >
                        {workerRows.reduce(
                          (sum, row) => sum + (Number(row.day) || 0),
                          0,
                        )}
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{
                          fontWeight: 'bold',
                          color: '#0284c7',
                          fontSize: '0.9rem',
                        }}
                      >
                        {workerRows.reduce(
                          (sum, row) => sum + (Number(row.night) || 0),
                          0,
                        )}
                      </TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </TableContainer>
            </Paper>
          </Box>

          <Box sx={{ p: 1.5, display: 'flex', justifyContent: 'center', gap: 1, borderTop: '1px solid #e2e8f0', bgcolor: '#f8fafc' }}>
            <Button variant="contained" size="small" onClick={handleSaveModal} sx={{ bgcolor: '#0284c7', px: 3, boxShadow: 'none' }}>저장</Button>
            <Button variant="outlined" size="small" onClick={handleCloseModal} sx={{ color: '#64748b', borderColor: '#cbd5e1', px: 3 }}>닫기</Button>
          </Box>
        </Box>
      </Modal>
    </Box>
  );
}
