import React, { useMemo, useState } from 'react';
import {
  Autocomplete,
  Box,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

import SystemPageTitle from '../components/SystemPageTitle.jsx';
const pad2 = (value) => String(value).padStart(2, '0');
const TOTAL_DAY_COLUMNS = 31;

const createDateKey = (year, monthIndex, day) => {
  const yy = String(year).slice(2);
  return `${yy}.${pad2(monthIndex + 1)}.${pad2(day)}`;
};

const normalizeWorkerName = (name) =>
  String(name || '')
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();

const DAILY_REPORT_JOB_ORDER = [
  '소장',
  '관리자',
  '직영',
  '먹매김',
  '단열',
  '합지',
  '경량벽체',
  '세대천정',
  '공용홀천정',
  '몰딩',
  '걸레받이',
  '수장',
  '외주',
  '기타',
];

const getJobOrder = (job) => {
  const index = DAILY_REPORT_JOB_ORDER.indexOf(
    String(job || '').trim(),
  );

  return index === -1
    ? DAILY_REPORT_JOB_ORDER.length
    : index;
};

const getWeekendStyle = (year, monthIndex, day) => {
  const dayOfWeek = new Date(year, monthIndex, day).getDay();

  if (dayOfWeek === 0) {
    return {
      color: '#dc2626',
      bgcolor: '#fff1f2',
    };
  }

  if (dayOfWeek === 6) {
    return {
      color: '#2563eb',
      bgcolor: '#eff6ff',
    };
  }

  return {
    color: '#334155',
    bgcolor: '#f8fafc',
  };
};

export default function MonthlyWorkerStatus({
  projectName = '',
  savedData = {},
  viewYear,
  viewMonth,
  handlePrevMonth,
  handleNextMonth,
}) {
  const [searchName, setSearchName] = useState('');
  const [searchJob, setSearchJob] = useState('');

  const daysInMonth = new Date(
    viewYear,
    viewMonth + 1,
    0,
  ).getDate();

  const monthNumber = viewMonth + 1;
  const workers = useMemo(() => {
    const workerMap = new Map();

    for (let day = 1; day <= daysInMonth; day += 1) {
      const dateKey = createDateKey(
        viewYear,
        viewMonth,
        day,
      );
      const dailyWorkers = Array.isArray(
        savedData?.[dateKey]?.workers,
      )
        ? savedData[dateKey].workers
        : [];

      dailyWorkers.forEach((worker) => {
        const name = String(worker?.name || '').trim();
        const job = String(worker?.job || '').trim();

        if (!name) return;

        /*
          같은 이름이 다른 직종으로 등록된 경우를 구분하기 위해
          직종과 성명을 합친 값을 근로자 식별 기준으로 사용합니다.
        */
        const workerKey = `${job}::${normalizeWorkerName(name)}`;

        if (!workerMap.has(workerKey)) {
          workerMap.set(workerKey, {
            key: workerKey,
            job: job || '미지정',
            name,
            attendance: {},
          });
        }

        /*
          월별 투입현황은 날짜별 근로 여부를 표시합니다.
          같은 사람이 하루에 중복 등록돼도 해당 날짜는 1일로 집계합니다.
        */
        workerMap.get(workerKey).attendance[day] = 1;
      });
    }

    return Array.from(workerMap.values()).sort((a, b) => {
      const jobOrderCompare =
        getJobOrder(a.job) - getJobOrder(b.job);

      if (jobOrderCompare !== 0) {
        return jobOrderCompare;
      }

      const jobCompare = a.job.localeCompare(
        b.job,
        'ko',
        { numeric: true },
      );

      if (jobCompare !== 0) {
        return jobCompare;
      }

      return a.name.localeCompare(
        b.name,
        'ko',
        { numeric: true },
      );
    });
  }, [daysInMonth, savedData, viewMonth, viewYear]);

  const normalizedNameSearch =
    normalizeWorkerName(searchName);

  const normalizedJobSearch =
    normalizeWorkerName(searchJob);

  const workerNameOptions = useMemo(
    () =>
      Array.from(
        new Set(
          workers
            .map((worker) => worker.name)
            .filter(Boolean),
        ),
      ).sort((a, b) =>
        a.localeCompare(b, 'ko', { numeric: true }),
      ),
    [workers],
  );

  const workerJobOptions = useMemo(
    () =>
      Array.from(
        new Set(
          workers
            .map((worker) => worker.job)
            .filter(Boolean),
        ),
      ).sort((a, b) => {
        const orderCompare =
          getJobOrder(a) - getJobOrder(b);

        if (orderCompare !== 0) {
          return orderCompare;
        }

        return a.localeCompare(
          b,
          'ko',
          { numeric: true },
        );
      }),
    [workers],
  );

  const filteredWorkers = useMemo(
    () =>
      workers.filter((worker) => {
        const nameMatched =
          !normalizedNameSearch ||
          normalizeWorkerName(
            worker.name,
          ).includes(
            normalizedNameSearch,
          );

        const jobMatched =
          !normalizedJobSearch ||
          normalizeWorkerName(
            worker.job,
          ).includes(
            normalizedJobSearch,
          );

        return (
          nameMatched &&
          jobMatched
        );
      }),
    [
      normalizedJobSearch,
      normalizedNameSearch,
      workers,
    ],
  );

  const hasSearchCondition =
    Boolean(
      normalizedNameSearch ||
        normalizedJobSearch,
    );

  const dayColumns = Array.from(
    { length: TOTAL_DAY_COLUMNS },
    (_, index) => {
      const columnDate = new Date(
        viewYear,
        viewMonth,
        index + 1,
      );
      const isOverflow = index >= daysInMonth;

      return {
        key: `${columnDate.getFullYear()}-${columnDate.getMonth()}-${columnDate.getDate()}`,
        day: columnDate.getDate(),
        monthIndex: columnDate.getMonth(),
        year: columnDate.getFullYear(),
        isOverflow,
        label: isOverflow
          ? `${columnDate.getMonth() + 1}/${columnDate.getDate()}`
          : columnDate.getDate(),
      };
    },
  );

  const attendanceSubtotal = useMemo(() => {
    const dailyTotals = Array.from(
      { length: TOTAL_DAY_COLUMNS },
      (_, index) => {
        if (index >= daysInMonth) return null;

        const day = index + 1;

        return filteredWorkers.reduce(
          (total, worker) =>
            total + Number(worker.attendance[day] || 0),
          0,
        );
      },
    );

    return {
      dailyTotals,
      grandTotal: dailyTotals.reduce(
        (total, dailyTotal) => total + dailyTotal,
        0,
      ),
    };
  }, [daysInMonth, filteredWorkers]);

  const stickyHeaderStyle = {
    position: 'sticky',
    zIndex: 5,
    bgcolor: '#f1f5f9',
    borderRight: '1px solid #94a3b8',
    borderBottom: '1px solid #64748b',
    fontWeight: 900,
    color: '#1e293b',
    py: 0.7,
    px: 0.5,
    whiteSpace: 'nowrap',
  };

  return (
    <Box
      sx={{
        height: '100%',
        minHeight: 0,
        display: 'flex',
        flexDirection: 'column',
        gap: 1.2,
      }}
    >
      <Paper
        variant="outlined"
        sx={{
          px: 1.5,
          py: 1.2,
          borderColor: '#cbd5e1',
          boxShadow: 'none',
          bgcolor: '#ffffff',
        }}
      >
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns:
              'minmax(240px, 1fr) minmax(320px, 1.5fr)',
            alignItems: 'stretch',
            border: '1px solid #64748b',
          }}
        >
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '68px 1fr',
              minHeight: 72,
              borderRight: '1px solid #64748b',
            }}
          >
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRight: '1px solid #64748b',
                bgcolor: '#f8fafc',
              }}
            >
              <Typography
                sx={{
                  fontSize: '0.72rem',
                  fontWeight: 900,
                  letterSpacing: '0.08em',
                }}
              >
                현장명
              </Typography>
            </Box>

            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                px: 1.4,
              }}
            >
              <Typography
                sx={{
                  fontSize: '0.82rem',
                  fontWeight: 800,
                  color: '#0f172a',
                }}
              >
                {projectName || '현장명 미등록'}
              </Typography>
            </Box>
          </Box>

          <Box
            sx={{
              minHeight: 72,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 0.2,
            }}
          >
            <SystemPageTitle
              title="금월 투입현황"
              help="선택한 월의 근로자별 투입일과 일자별 인원 소계를 조회합니다."
            />

            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 0.4,
              }}
            >
              <IconButton
                size="small"
                onClick={handlePrevMonth}
                aria-label="이전 달"
                sx={{ p: 0.15 }}
              >
                <ChevronLeftIcon fontSize="small" />
              </IconButton>

              <Typography
                sx={{
                  minWidth: 92,
                  textAlign: 'center',
                  fontSize: '0.74rem',
                  fontWeight: 800,
                  color: '#475569',
                }}
              >
                {viewYear}년 {pad2(monthNumber)}월
              </Typography>

              <IconButton
                size="small"
                onClick={handleNextMonth}
                aria-label="다음 달"
                sx={{ p: 0.15 }}
              >
                <ChevronRightIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>

        </Box>

        <Box
          sx={{
            mt: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 1,
          }}
        >
          <Typography
            sx={{
              color: '#64748b',
              fontSize: '0.72rem',
              fontWeight: 700,
            }}
          >
            등록 근로자 {workers.length.toLocaleString()}명
            {hasSearchCondition
              ? ` · 조회 결과 ${filteredWorkers.length.toLocaleString()}명`
              : ''}
          </Typography>

          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 0.8,
            }}
          >
            <Autocomplete
              freeSolo
              openOnFocus
              options={workerNameOptions}
              inputValue={searchName}
              onInputChange={(_event, nextValue) => {
                setSearchName(nextValue);
              }}
              onChange={(_event, nextValue) => {
                setSearchName(nextValue || '');
              }}
              filterOptions={(options, state) => {
                const keyword = normalizeWorkerName(
                  state.inputValue,
                );

                if (!keyword) {
                  return options.slice(0, 8);
                }

                return options
                  .filter((name) =>
                    normalizeWorkerName(name).includes(keyword),
                  )
                  .slice(0, 8);
              }}
              noOptionsText="검색된 근로자가 없습니다."
              sx={{
                width: 230,
                '& .MuiInputBase-root': {
                  minHeight: 34,
                  bgcolor: '#ffffff',
                  fontSize: '0.78rem',
                },
                '& .MuiInputLabel-root': {
                  fontSize: '0.76rem',
                },
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  size="small"
                  label="근로자 조회(성명)"
                  placeholder="성명 입력"
                />
              )}
            />

            <Autocomplete
              freeSolo
              openOnFocus
              options={workerJobOptions}
              inputValue={searchJob}
              onInputChange={(_event, nextValue) => {
                setSearchJob(nextValue);
              }}
              onChange={(_event, nextValue) => {
                setSearchJob(nextValue || '');
              }}
              filterOptions={(options, state) => {
                const keyword = normalizeWorkerName(
                  state.inputValue,
                );

                if (!keyword) {
                  return options.slice(0, 10);
                }

                return options
                  .filter((job) =>
                    normalizeWorkerName(job).includes(keyword),
                  )
                  .slice(0, 10);
              }}
              noOptionsText="검색된 직종이 없습니다."
              sx={{
                width: 200,
                '& .MuiInputBase-root': {
                  minHeight: 34,
                  bgcolor: '#ffffff',
                  fontSize: '0.78rem',
                },
                '& .MuiInputLabel-root': {
                  fontSize: '0.76rem',
                },
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  size="small"
                  label="직종 조회"
                  placeholder="예: 직영"
                />
              )}
            />
          </Box>
        </Box>
      </Paper>

      <TableContainer
        component={Paper}
        variant="outlined"
        sx={{
          flexGrow: 1,
          minHeight: 0,
          overflow: 'auto',
          borderColor: '#94a3b8',
          boxShadow: 'none',
          bgcolor: '#ffffff',
        }}
      >
        <Table
          stickyHeader
          size="small"
          sx={{
            minWidth: 300 + TOTAL_DAY_COLUMNS * 34,
            tableLayout: 'fixed',
            borderCollapse: 'separate',
            borderSpacing: 0,
          }}
        >
          <TableHead>
            <TableRow>
              <TableCell
                align="center"
                sx={{
                  ...stickyHeaderStyle,
                  left: 0,
                  width: 44,
                  minWidth: 44,
                  maxWidth: 44,
                  zIndex: 8,
                }}
              >
                No.
              </TableCell>

              <TableCell
                align="center"
                sx={{
                  ...stickyHeaderStyle,
                  left: 44,
                  width: 88,
                  minWidth: 88,
                  maxWidth: 88,
                  zIndex: 8,
                }}
              >
                직종
              </TableCell>

              <TableCell
                align="center"
                sx={{
                  ...stickyHeaderStyle,
                  left: 132,
                  width: 112,
                  minWidth: 112,
                  maxWidth: 112,
                  zIndex: 8,
                  boxShadow: '2px 0 0 #94a3b8',
                }}
              >
                성명
              </TableCell>

              {dayColumns.map((column) => {
                const weekendStyle = getWeekendStyle(
                  column.year,
                  column.monthIndex,
                  column.day,
                );

                return (
                  <TableCell
                    key={column.key}
                    align="center"
                    sx={{
                      ...stickyHeaderStyle,
                      position: 'sticky',
                      top: 0,
                      width: 34,
                      minWidth: 34,
                      maxWidth: 34,
                      color: column.isOverflow
                        ? '#64748b'
                        : weekendStyle.color,
                      bgcolor: column.isOverflow
                        ? '#d1d5db'
                        : weekendStyle.bgcolor,
                      px: 0,
                    }}
                  >
                    {column.label}
                  </TableCell>
                );
              })}

              <TableCell
                align="center"
                sx={{
                  ...stickyHeaderStyle,
                  right: 0,
                  width: 56,
                  minWidth: 56,
                  maxWidth: 56,
                  zIndex: 8,
                  boxShadow: '-2px 0 0 #94a3b8',
                }}
              >
                합계
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {filteredWorkers.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={TOTAL_DAY_COLUMNS + 4}
                  align="center"
                  sx={{
                    py: 7,
                    color: '#64748b',
                    fontSize: '0.82rem',
                  }}
                >
                  {hasSearchCondition
                    ? '검색 조건에 맞는 근로자가 없습니다.'
                    : '해당 월에 등록된 근로자가 없습니다.'}
                </TableCell>
              </TableRow>
            ) : (
              <React.Fragment>
                {filteredWorkers.map((worker, index) => {
                  const totalAttendance = dayColumns.reduce(
                    (total, column) =>
                      column.isOverflow
                        ? total
                        : total +
                          Number(worker.attendance[column.day] || 0),
                    0,
                  );

                  return (
                  <TableRow
                    key={worker.key}
                    hover
                  >
                    <TableCell
                      align="center"
                      sx={{
                        position: 'sticky',
                        left: 0,
                        zIndex: 3,
                        width: 44,
                        minWidth: 44,
                        maxWidth: 44,
                        px: 0.4,
                        py: 0.65,
                        bgcolor: '#ffffff',
                        borderRight: '1px solid #cbd5e1',
                        fontSize: '0.7rem',
                      }}
                    >
                      {index + 1}
                    </TableCell>

                    <TableCell
                      align="center"
                      sx={{
                        position: 'sticky',
                        left: 44,
                        zIndex: 3,
                        width: 88,
                        minWidth: 88,
                        maxWidth: 88,
                        px: 0.5,
                        py: 0.65,
                        bgcolor: '#ffffff',
                        borderRight: '1px solid #cbd5e1',
                        fontSize: '0.7rem',
                        fontWeight: 700,
                        color: '#475569',
                      }}
                    >
                      {worker.job}
                    </TableCell>

                    <TableCell
                      align="center"
                      sx={{
                        position: 'sticky',
                        left: 132,
                        zIndex: 3,
                        width: 112,
                        minWidth: 112,
                        maxWidth: 112,
                        px: 0.5,
                        py: 0.65,
                        bgcolor: '#ffffff',
                        borderRight: '1px solid #94a3b8',
                        boxShadow: '2px 0 0 #e2e8f0',
                        fontSize: '0.72rem',
                        fontWeight: 800,
                        color: '#0f172a',
                      }}
                    >
                      {worker.name}
                    </TableCell>

                    {dayColumns.map((column) => {
                      const attended = column.isOverflow
                        ? 0
                        : Number(
                            worker.attendance[column.day] || 0,
                          );
                      const weekendStyle = getWeekendStyle(
                        column.year,
                        column.monthIndex,
                        column.day,
                      );

                      return (
                        <TableCell
                          key={`${worker.key}-${column.key}`}
                          align="center"
                          sx={{
                            width: 34,
                            minWidth: 34,
                            maxWidth: 34,
                            px: 0,
                            py: 0.65,
                            borderRight: '1px dotted #cbd5e1',
                            bgcolor: column.isOverflow
                              ? '#e5e7eb'
                              : weekendStyle.bgcolor === '#f8fafc'
                                ? '#ffffff'
                                : weekendStyle.bgcolor,
                            color: attended
                              ? '#0f172a'
                              : '#cbd5e1',
                            fontSize: '0.7rem',
                            fontWeight: attended ? 800 : 400,
                          }}
                        >
                          {column.isOverflow ? '' : attended || ''}
                        </TableCell>
                      );
                    })}

                    <TableCell
                      align="center"
                      sx={{
                        position: 'sticky',
                        right: 0,
                        zIndex: 3,
                        width: 56,
                        minWidth: 56,
                        maxWidth: 56,
                        px: 0.4,
                        py: 0.65,
                        bgcolor: '#f8fafc',
                        borderLeft: '1px solid #94a3b8',
                        fontSize: '0.72rem',
                        fontWeight: 900,
                        color: '#0369a1',
                      }}
                    >
                      {totalAttendance}
                    </TableCell>
                  </TableRow>
                );
                })}

                <TableRow>
                  <TableCell
                    colSpan={3}
                    align="center"
                    sx={{
                      position: 'sticky',
                      left: 0,
                      zIndex: 4,
                      px: 0.5,
                      py: 0.72,
                      bgcolor: '#e0f2fe',
                      borderTop: '2px solid #0284c7',
                      borderRight: '1px solid #94a3b8',
                      boxShadow: '2px 0 0 #bae6fd',
                      fontSize: '0.74rem',
                      fontWeight: 900,
                      color: '#075985',
                    }}
                  >
                    소계
                  </TableCell>

                  {attendanceSubtotal.dailyTotals.map(
                    (dailyTotal, index) => (
                      <TableCell
                        key={`subtotal-${index + 1}`}
                        align="center"
                        sx={{
                          width: 34,
                          minWidth: 34,
                          maxWidth: 34,
                          px: 0,
                          py: 0.72,
                          bgcolor: dailyTotal === null
                            ? '#d1d5db'
                            : '#e0f2fe',
                          borderTop: '2px solid #0284c7',
                          borderRight: '1px dotted #7dd3fc',
                          fontSize: '0.72rem',
                          fontWeight: 900,
                          color: dailyTotal === null
                            ? '#94a3b8'
                            : '#075985',
                        }}
                      >
                        {dailyTotal === null ? '' : dailyTotal}
                      </TableCell>
                    ),
                  )}

                  <TableCell
                    align="center"
                    sx={{
                      position: 'sticky',
                      right: 0,
                      zIndex: 4,
                      width: 56,
                      minWidth: 56,
                      maxWidth: 56,
                      px: 0.4,
                      py: 0.72,
                      bgcolor: '#bae6fd',
                      borderTop: '2px solid #0284c7',
                      borderLeft: '1px solid #0284c7',
                      fontSize: '0.76rem',
                      fontWeight: 900,
                      color: '#075985',
                    }}
                  >
                    {attendanceSubtotal.grandTotal}
                  </TableCell>
                </TableRow>
              </React.Fragment>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
