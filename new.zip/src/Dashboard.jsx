import React, { useState } from 'react';
import { Box, Drawer, AppBar, Toolbar, List, Typography, Paper, ListItemButton, ListItemIcon, ListItemText, IconButton, Button, Link, TextField, Divider, Modal, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Checkbox, Autocomplete, InputBase } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import EngineeringIcon from '@mui/icons-material/Engineering';
import InventoryIcon from '@mui/icons-material/Inventory';
import AssignmentIcon from '@mui/icons-material/Assignment';
import CloseIcon from '@mui/icons-material/Close';

const drawerWidth = 240;

// 💡 1. 초기 상태 데이터를 밖에서 정의합니다 (나중에 useState에 넣기 위함)
const initialWeekDays = [
  { date: '26.07.05', dayName: '일', isToday: false, workers: 0 },
  { date: '26.07.06', dayName: '월', isToday: false, workers: 0 },
  { date: '26.07.07', dayName: '화', isToday: true, workers: 0 }, 
  { date: '26.07.08', dayName: '수', isToday: false, workers: 0 },
  { date: '26.07.09', dayName: '목', isToday: false, workers: 0 },
  { date: '26.07.10', dayName: '금', isToday: false, workers: 0 },
  { date: '26.07.11', dayName: '토', isToday: false, workers: 0 },
];

const calendarCells = Array.from({ length: 35 }, (_, i) => {
  if (i < 3) return null;
  if (i - 3 < 31) return i - 2;
  return null;
});

const jobOptions = ['직영', '먹매김', '단열', '합지', '경량벽체', '세대천정', '공용홀천정', '몰딩', '걸레받이', '수장', '외주', '기타', '용역'];

const modalStyle = {
  position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
  width: '85vw', maxWidth: '1200px', height: '80vh',
  bgcolor: 'background.paper', boxShadow: 24, borderRadius: '8px',
  display: 'flex', flexDirection: 'column', overflow: 'hidden',
};

const headerCellStyle = { borderRight: '1px solid #cbd5e1', fontWeight: 'bold', color: '#334155', py: 1 };
const bodyCellStyle = { borderRight: '1px solid #cbd5e1', p: 0 }; 

export default function Dashboard() {
  const [open, setOpen] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedDateKey, setSelectedDateKey] = useState(''); // 어떤 날짜를 선택했는지 (예: 26.07.08)
  const [selectedDateDisplay, setSelectedDateDisplay] = useState(''); // 화면에 보여줄 텍스트

  // 💡 2. 메인 화면의 요일별 카드 데이터를 상태(State)로 관리합니다.
  const [weekDays, setWeekDays] = useState(initialWeekDays);
  
  // 💡 3. 가상의 데이터베이스! 각 날짜별로 작성한 표 데이터를 이곳에 임시 저장합니다.
  const [savedData, setSavedData] = useState({});

  // 팝업 내부 표 상태
  const [workerRows, setWorkerRows] = useState([]);
  const [taskRows, setTaskRows] = useState([]);
  const [selectedWorkers, setSelectedWorkers] = useState([]);
  const [selectedTasks, setSelectedTasks] = useState([]);

  const toggleDrawer = () => setOpen(!open);

  // 💡 [수정됨] 팝업 열기: 저장된 데이터가 있으면 불러오고, 없으면 빈 화면을 띄웁니다.
  const handleOpenModal = (day) => {
    setSelectedDateKey(day.date);
    setSelectedDateDisplay(`${day.date} (${day.dayName})`);
    
    // 저장된 데이터가 있으면 가져오고, 없으면 빈 배열로 세팅
    if (savedData[day.date]) {
      setWorkerRows(savedData[day.date].workers);
      setTaskRows(savedData[day.date].tasks);
    } else {
      setWorkerRows([]);
      setTaskRows([]);
    }
    
    setModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setModalOpen(false);
    setSelectedWorkers([]); setSelectedTasks([]);
  };

  // =========================================================
  // 💡 4. [핵심] 저장 버튼을 눌렀을 때 실행되는 함수
  // =========================================================
  const handleSaveModal = () => {
    // 1. 현재 작성한 표 데이터를 가상 DB에 저장
    setSavedData(prev => ({
      ...prev,
      [selectedDateKey]: {
        workers: workerRows,
        tasks: taskRows
      }
    }));

    // 2. 근로자 표에 작성된 사람 수(줄 수) 계산
    const totalWorkersCount = workerRows.length;

    // 3. 메인 화면 카드(weekDays)의 해당 날짜 'workers' 숫자를 업데이트
    setWeekDays(prev => prev.map(day => 
      day.date === selectedDateKey ? { ...day, workers: totalWorkersCount } : day
    ));

    // 4. 저장 완료 알림 후 팝업 닫기
    alert('저장되었습니다!');
    handleCloseModal();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      if (e.defaultPrevented) return; 
      e.preventDefault(); 
      const inputs = Array.from(document.querySelectorAll('.excel-input'));
      const index = inputs.indexOf(e.target);
      setTimeout(() => {
        if (index > -1 && index < inputs.length - 1) inputs[index + 1].focus();
      }, 50);
    }
  };

  // 표 조작 함수들...
  const fetchPreviousWorkers = () => setWorkerRows([{ id: Date.now(), job: '직영', name: '김반장', day: 1, night: 0 }]);
  const handleAddWorker = () => setWorkerRows([...workerRows, { id: Date.now(), job: null, name: '', day: 0, night: 0 }]);
  const handleDeleteWorkers = () => {
    setWorkerRows(workerRows.filter(row => !selectedWorkers.includes(row.id)));
    setSelectedWorkers([]);
  };
  const handleSelectAllWorkers = (e) => e.target.checked ? setSelectedWorkers(workerRows.map(row => row.id)) : setSelectedWorkers([]);
  const handleSelectWorker = (id) => selectedWorkers.includes(id) ? setSelectedWorkers(selectedWorkers.filter(item => item !== id)) : setSelectedWorkers([...selectedWorkers, id]);
  const handleWorkerChange = (id, field, value) => setWorkerRows(prev => prev.map(row => row.id === id ? { ...row, [field]: value } : row));

  const fetchPreviousTasks = () => setTaskRows([{ id: Date.now(), taskName: '몰딩 작업', amount: '1식' }]);
  const handleAddTask = () => setTaskRows([...taskRows, { id: Date.now(), taskName: '', amount: '' }]);
  const handleDeleteTasks = () => {
    setTaskRows(taskRows.filter(row => !selectedTasks.includes(row.id)));
    setSelectedTasks([]);
  };
  const handleSelectAllTasks = (e) => e.target.checked ? setSelectedTasks(taskRows.map(row => row.id)) : setSelectedTasks([]);
  const handleSelectTask = (id) => selectedTasks.includes(id) ? setSelectedTasks(selectedTasks.filter(item => item !== id)) : setSelectedTasks([...selectedTasks, id]);
  const handleTaskChange = (id, field, value) => setTaskRows(prev => prev.map(row => row.id === id ? { ...row, [field]: value } : row));

  return (
    <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <AppBar position="absolute" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, bgcolor: '#1e293b' }}>
        <Toolbar sx={{ minHeight: '56px !important' }}>
          <IconButton edge="start" color="inherit" onClick={toggleDrawer} sx={{ marginRight: '36px' }}><MenuIcon /></IconButton>
          <Typography component="h1" variant="subtitle1" color="inherit" noWrap sx={{ flexGrow: 1, fontWeight: 'bold' }}>🏗️ 스마트 공사 관리 - 협력사 작업일보 작성</Typography>
        </Toolbar>
      </AppBar>

      <Drawer variant="permanent" open={open} sx={{
        width: open ? drawerWidth : 72, flexShrink: 0,
        [`& .MuiDrawer-paper`]: { width: open ? drawerWidth : 72, boxSizing: 'border-box', overflowX: 'hidden', transition: 'width 0.3s', bgcolor: '#0f172a', color: 'white' },
      }}>
        <Toolbar sx={{ minHeight: '56px !important' }} />
        <Box sx={{ overflow: 'auto' }}>
          <List component="nav">
            <ListItemButton selected sx={{ bgcolor: 'rgba(255,255,255,0.1)' }}><ListItemIcon><EngineeringIcon sx={{ color: 'white' }} /></ListItemIcon><ListItemText primary="공사일보 관리" /></ListItemButton>
            <ListItemButton><ListItemIcon><InventoryIcon sx={{ color: '#94a3b8' }} /></ListItemIcon><ListItemText primary="자재 반입 현황" sx={{ color: '#94a3b8' }} /></ListItemButton>
            <ListItemButton><ListItemIcon><AssignmentIcon sx={{ color: '#94a3b8' }} /></ListItemIcon><ListItemText primary="공정표 및 결재" sx={{ color: '#94a3b8' }} /></ListItemButton>
          </List>
        </Box>
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, height: '100vh', display: 'flex', flexDirection: 'column', bgcolor: '#f1f5f9' }}>
        <Toolbar sx={{ minHeight: '56px !important' }} />
        <Box sx={{ p: 2, flexGrow: 1, overflow: 'hidden' }}>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gridTemplateRows: 'repeat(2, 1fr)', gap: 2, height: '100%' }}>
            
            <Paper sx={{ p: 1.5, display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="subtitle2" fontWeight="bold">기간 선택</Typography>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 'bold' }}>{"< 2026.07 >"}</Typography>
              </Box>
              <Divider sx={{ mb: 1.5 }} />
              <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', textAlign: 'center', mb: 0.5 }}>
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, idx) => (
                  <Typography key={day} variant="caption" sx={{ fontSize: '0.65rem', fontWeight: 'bold', color: idx === 0 ? '#ef4444' : idx === 6 ? '#3b82f6' : '#64748b' }}>{day}</Typography>
                ))}
              </Box>
              <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', textAlign: 'center' }}>
                {calendarCells.map((day, index) => {
                  const weekIdx = Math.floor(index / 7);
                  const isCurrentWeek = weekIdx === 1;
                  const dayIdx = index % 7;
                  const isToday = day === 7;
                  const currentWeekWorkers = weekDays.map(day => `${day.workers}명`);
                  return (
                    <Box key={index} sx={{ 
                      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start',
                      bgcolor: isCurrentWeek ? '#e0f2fe' : 'transparent', py: 0.5,
                      borderTopLeftRadius: dayIdx === 0 ? '6px' : '0', borderBottomLeftRadius: dayIdx === 0 ? '6px' : '0',
                      borderTopRightRadius: dayIdx === 6 ? '6px' : '0', borderBottomRightRadius: dayIdx === 6 ? '6px' : '0',
                    }}>
                      {day && (
                        <>
                          <Box sx={{ 
                            width: 20, height: 20, borderRadius: '50%', 
                            bgcolor: isToday ? '#ef4444' : 'transparent', color: isToday ? 'white' : (dayIdx === 0 ? '#ef4444' : dayIdx === 6 ? '#3b82f6' : '#334155'),
                            lineHeight: '20px', fontSize: '0.7rem', fontWeight: isToday ? 'bold' : 'normal'
                          }}>{day}</Box>
                          {isCurrentWeek ? <Typography variant="caption" sx={{ color: '#0ea5e9', fontSize: '0.6rem', fontWeight: 'bold', mt: 0.2 }}>{currentWeekWorkers[dayIdx]}</Typography> : <Box sx={{ height: '14px', mt: 0.2 }} />}
                        </>
                      )}
                    </Box>
                  );
                })}
              </Box>
              <Box sx={{ mt: 'auto', textAlign: 'center' }}><Button variant="contained" color="success" size="small" fullWidth sx={{ py: 0.8, fontSize: '0.8rem', fontWeight: 'bold' }}>출력일보 주별 다운로드</Button></Box>
            </Paper>

            {/* 💡 5. 화면에 보여주는 데이터를 상태값인 'weekDays'로 연결 */}
            {weekDays.map((day) => (
              <Paper key={day.date} sx={{ p: 1.5, display: 'flex', flexDirection: 'column', borderTop: day.isToday ? '4px solid #0ea5e9' : '4px solid transparent', overflowY: 'auto' }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                  <Typography variant="subtitle2" fontWeight="bold">{day.date} ({day.dayName}) </Typography>
                  <Button variant="contained" color="success" size="small" sx={{ minWidth: 0, px: 1, py: 0.2, fontSize: '0.7rem' }}>XLS</Button>
                </Box>
                <Divider sx={{ mb: 1 }} />
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <Typography variant="caption" fontWeight="bold" sx={{ color: 'white', bgcolor: '#0f766e', px: 0.5, py: 0.2, borderRadius: 1 }}>건축</Typography>
                    <Typography variant="caption" fontWeight="bold">내장공사</Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>ㅇㅇ건설 · 김반장</Typography>
                  </Box>
                  <Typography variant="caption" sx={{ bgcolor: '#334155', color: 'white', px: 0.5, py: 0.2, borderRadius: 1, fontSize: '0.65rem' }}>출역일보</Typography>
                </Box>
                <Box sx={{ mb: 1.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    {/* 💡 실시간으로 연동되는 인원 수! */}
                    <Typography variant="caption" fontWeight="bold">투입 인원 (총원 {day.workers}명)</Typography>
                    <Link onClick={() => handleOpenModal(day)} underline="hover" sx={{ fontSize: '0.75rem', color: '#0ea5e9', cursor: 'pointer' }}>근로자(직종) 추가</Link>
                  </Box>
                </Box>
                <Typography variant="caption" fontWeight="bold" sx={{ fontSize: '0.7rem' }}>금일 작업</Typography>
                <TextField multiline rows={2} fullWidth size="small" sx={{ mb: 1, '& .MuiInputBase-root': { fontSize: '0.75rem', p: 0.8 } }} />
                <Typography variant="caption" fontWeight="bold" sx={{ fontSize: '0.7rem' }}>명일 작업</Typography>
                <TextField multiline rows={1} fullWidth size="small" sx={{ mb: 1.5, '& .MuiInputBase-root': { fontSize: '0.75rem', p: 0.8 } }} />
                <Box sx={{ mt: 'auto', display: 'flex', justifyContent: 'center', gap: 1, pt: 1 }}>
                  <Button variant="contained" color="error" size="small" sx={{ fontSize: '0.7rem', py: 0.3, fontWeight: 'bold' }}>작업없음</Button>
                  <Button variant="contained" sx={{ bgcolor: '#475569', '&:hover': { bgcolor: '#334155' }, fontSize: '0.7rem', py: 0.3, fontWeight: 'bold' }} size="small">이전_작업_가져오기</Button>
                </Box>
              </Paper>
            ))}
          </Box>
        </Box>

        <Modal open={modalOpen} onClose={handleCloseModal}>
          <Box sx={modalStyle}>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2, bgcolor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
              <Typography variant="subtitle1" fontWeight="bold" color="#334155">내장공사 / [{selectedDateDisplay}]</Typography>
              <IconButton onClick={handleCloseModal} size="small"><CloseIcon /></IconButton>
            </Box>

            <Box sx={{ flexGrow: 1, display: 'flex', p: 2, gap: 2, overflow: 'hidden', bgcolor: '#f1f5f9' }}>
              
              <Paper sx={{ flex: 1, display: 'flex', flexDirection: 'column', p: 1.5 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                  <Typography variant="subtitle2" fontWeight="bold">근로자</Typography>
                  <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                    <TextField size="small" type="date" defaultValue="2026-07-07" sx={{ '& .MuiInputBase-root': { fontSize: '0.75rem', py: 0.2 } }} />
                    <Button variant="contained" size="small" onClick={fetchPreviousWorkers} sx={{ bgcolor: '#0284c7', fontSize: '0.7rem', boxShadow: 'none' }}>가져오기</Button>
                    <Button variant="contained" size="small" onClick={handleAddWorker} sx={{ bgcolor: '#475569', fontSize: '0.7rem', boxShadow: 'none' }}>추가</Button>
                    <Button variant="contained" size="small" onClick={handleDeleteWorkers} sx={{ bgcolor: '#ef4444', fontSize: '0.7rem', boxShadow: 'none' }}>삭제</Button>
                  </Box>
                </Box>
                
                <TableContainer sx={{ flexGrow: 1, border: '1px solid #cbd5e1', borderRadius: '4px', bgcolor: 'white' }}>
                  <Table stickyHeader size="small" sx={{ minWidth: 400 }}>
                    <TableHead>
                      <TableRow sx={{ bgcolor: '#f8fafc' }}>
                        <TableCell padding="checkbox" sx={{ borderRight: '1px solid #cbd5e1' }}>
                          <Checkbox size="small" onChange={handleSelectAllWorkers} checked={workerRows.length > 0 && selectedWorkers.length === workerRows.length} indeterminate={selectedWorkers.length > 0 && selectedWorkers.length < workerRows.length} />
                        </TableCell>
                        <TableCell align="center" sx={{ ...headerCellStyle, width: '40px' }}>No.</TableCell>
                        <TableCell align="center" sx={{ ...headerCellStyle, width: '120px' }}>직종</TableCell>
                        <TableCell align="center" sx={headerCellStyle}>성명</TableCell>
                        <TableCell align="center" sx={{ ...headerCellStyle, width: '60px' }}>주간</TableCell>
                        <TableCell align="center" sx={{ fontWeight: 'bold', color: '#334155', py: 1, width: '60px' }}>야간</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {workerRows.length === 0 ? (
                        <TableRow><TableCell colSpan={6} align="center" sx={{ py: 10, color: 'text.secondary', borderBottom: 'none' }}>데이터가 존재하지 않습니다.</TableCell></TableRow>
                      ) : (
                        workerRows.map((row, idx) => (
                          <TableRow hover key={row.id}>
                            <TableCell padding="checkbox" sx={{ borderRight: '1px solid #cbd5e1' }}>
                              <Checkbox size="small" checked={selectedWorkers.includes(row.id)} onChange={() => handleSelectWorker(row.id)} />
                            </TableCell>
                            <TableCell align="center" sx={{ borderRight: '1px solid #cbd5e1', py: 0.5, color: '#334155' }}>{idx + 1}</TableCell>
                            
                            <TableCell align="center" sx={bodyCellStyle}>
                              <Autocomplete
                                options={jobOptions}
                                value={row.job}
                                onChange={(e, newValue) => handleWorkerChange(row.id, 'job', newValue)}
                                disableClearable
                                size="small"
                                autoHighlight 
                                renderInput={(params) => (
                                  <TextField 
                                    {...params} 
                                    variant="standard" 
                                    InputProps={{ ...params.InputProps, disableUnderline: true }}
                                    inputProps={{ 
                                      ...params.inputProps, 
                                      className: `${params.inputProps?.className || ''} excel-input` 
                                    }}
                                    onKeyDown={(e) => {
                                      if (params.inputProps?.onKeyDown) params.inputProps.onKeyDown(e);
                                      handleKeyDown(e);
                                    }}
                                    sx={{ '& input': { textAlign: 'center', fontSize: '0.8rem', py: 1 } }} 
                                  />
                                )}
                              />
                            </TableCell>
                            
                            <TableCell align="center" sx={bodyCellStyle}>
                              <InputBase className="excel-input" value={row.name} onKeyDown={handleKeyDown} onChange={(e) => handleWorkerChange(row.id, 'name', e.target.value)} sx={{ width: '100%', input: { textAlign: 'center', fontSize: '0.8rem' } }} />
                            </TableCell>
                            <TableCell align="center" sx={bodyCellStyle}>
                              <InputBase className="excel-input" type="number" value={row.day} onKeyDown={handleKeyDown} onChange={(e) => handleWorkerChange(row.id, 'day', Number(e.target.value))} sx={{ width: '100%', input: { textAlign: 'center', fontSize: '0.8rem' } }} />
                            </TableCell>
                            <TableCell align="center" sx={{ p: 0 }}>
                              <InputBase className="excel-input" type="number" value={row.night} onKeyDown={handleKeyDown} onChange={(e) => handleWorkerChange(row.id, 'night', Number(e.target.value))} sx={{ width: '100%', input: { textAlign: 'center', fontSize: '0.8rem' } }} />
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Paper>

              <Paper sx={{ flex: 1, display: 'flex', flexDirection: 'column', p: 1.5 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                  <Typography variant="subtitle2" fontWeight="bold">주요 작업</Typography>
                  <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                    <TextField size="small" type="date" defaultValue="2026-07-07" sx={{ '& .MuiInputBase-root': { fontSize: '0.75rem', py: 0.2 } }} />
                    <Button variant="contained" size="small" onClick={fetchPreviousTasks} sx={{ bgcolor: '#0284c7', fontSize: '0.7rem', boxShadow: 'none' }}>가져오기</Button>
                    <Button variant="contained" size="small" onClick={handleAddTask} sx={{ bgcolor: '#475569', fontSize: '0.7rem', boxShadow: 'none' }}>추가</Button>
                    <Button variant="contained" size="small" onClick={handleDeleteTasks} sx={{ bgcolor: '#ef4444', fontSize: '0.7rem', boxShadow: 'none' }}>삭제</Button>
                  </Box>
                </Box>

                <TableContainer sx={{ flexGrow: 1, border: '1px solid #cbd5e1', borderRadius: '4px', bgcolor: 'white' }}>
                  <Table stickyHeader size="small" sx={{ minWidth: 400 }}>
                    <TableHead>
                      <TableRow sx={{ bgcolor: '#f8fafc' }}>
                        <TableCell padding="checkbox" sx={{ borderRight: '1px solid #cbd5e1' }}>
                          <Checkbox size="small" onChange={handleSelectAllTasks} checked={taskRows.length > 0 && selectedTasks.length === taskRows.length} indeterminate={selectedTasks.length > 0 && selectedTasks.length < taskRows.length} />
                        </TableCell>
                        <TableCell align="center" sx={{ ...headerCellStyle, width: '40px' }}>No.</TableCell>
                        <TableCell align="center" sx={headerCellStyle}>주요 작업명</TableCell>
                        <TableCell align="center" sx={{ fontWeight: 'bold', color: '#334155', py: 1, width: '80px' }}>수량</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {taskRows.length === 0 ? (
                        <TableRow><TableCell colSpan={4} align="center" sx={{ py: 10, color: 'text.secondary', borderBottom: 'none' }}>데이터가 존재하지 않습니다.</TableCell></TableRow>
                      ) : (
                        taskRows.map((row, idx) => (
                          <TableRow hover key={row.id}>
                            <TableCell padding="checkbox" sx={{ borderRight: '1px solid #cbd5e1' }}>
                              <Checkbox size="small" checked={selectedTasks.includes(row.id)} onChange={() => handleSelectTask(row.id)} />
                            </TableCell>
                            <TableCell align="center" sx={{ borderRight: '1px solid #cbd5e1', py: 0.5, color: '#334155' }}>{idx + 1}</TableCell>
                            <TableCell align="center" sx={bodyCellStyle}>
                              <InputBase className="excel-input" value={row.taskName} onKeyDown={handleKeyDown} onChange={(e) => handleTaskChange(row.id, 'taskName', e.target.value)} sx={{ width: '100%', px: 1, input: { fontSize: '0.8rem' } }} />
                            </TableCell>
                            <TableCell align="center" sx={{ p: 0 }}>
                              <InputBase className="excel-input" value={row.amount} onKeyDown={handleKeyDown} onChange={(e) => handleTaskChange(row.id, 'amount', e.target.value)} sx={{ width: '100%', input: { textAlign: 'center', fontSize: '0.8rem' } }} />
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Paper>

            </Box>

            <Box sx={{ p: 1.5, display: 'flex', justifyContent: 'center', gap: 1, borderTop: '1px solid #e2e8f0', bgcolor: '#f8fafc' }}>
              {/* 💡 6. 저장 버튼에 만든 함수 연결! */}
              <Button variant="contained" size="small" onClick={handleSaveModal} sx={{ bgcolor: '#0284c7', px: 3, boxShadow: 'none' }}>저장</Button>
              <Button variant="outlined" size="small" onClick={handleCloseModal} sx={{ color: '#64748b', borderColor: '#cbd5e1', px: 3 }}>닫기</Button>
            </Box>

          </Box>
        </Modal>
      </Box>
    </Box>
  );
}